/*
 * Copyright (C) 2005 Meilhaus Electronic GmbH (support@meilhaus.de)
 *
 * Source File : query.c
 * Author      : GG (Guenter Gebhardt)  <g.gebhardt@meilhaus.de>
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <medriver.h>
char* meDevTypes[] =
{
	"ME_TYPE_INVALID",
	"ME_TYPE_AO",
	"ME_TYPE_AI",
	"ME_TYPE_DIO",
	"ME_TYPE_DO",
	"ME_TYPE_DI",
	"ME_TYPE_CTR",
	"ME_TYPE_EXT_IRQ"
};

char* meSubDevTypes[] =
{
	"ME_SUBTYPE_INVALID",
	"ME_SUBTYPE_SINGLE",
	"ME_SUBTYPE_STREAMING",
	"ME_SUBTYPE_CTR_8254",
	"ME_SUBTYPE_ANY"};

char* typetostr(int number);
char* subtypetostr(int number);

int main(int argc, char *argv[]){
	int err;
	int i, j, k;
	char err_msg[ME_ERROR_MSG_MAX_COUNT] = {0};
	char description[ME_DEVICE_DESCRIPTION_MAX_COUNT] = {0};
	char name_device[ME_DEVICE_NAME_MAX_COUNT] = {0};
	char name_driver[ME_DEVICE_DRIVER_NAME_MAX_COUNT] = {0};
	int d_version;
	int l_version;
	int n_devices;
	int n_subdevices;
	int n_channels;
	int n_ranges;
	int unit;
	double min;
	double max;
	int max_data;
	int type;
	int subtype;

	err = meOpen(0);
	if(err){
		meErrorGetMessage(err, err_msg, sizeof(err_msg));
		fprintf(stderr, "In meOpen(): %s\n", err_msg);
		return 1;
	}

	err = meQueryVersionLibrary(&l_version);
	if(err){
		meErrorGetMessage(err, err_msg, sizeof(err_msg));
		fprintf(stderr, "In meQueryLibraryVersion(): %s\n", err_msg);
		return 1;
	}
	printf("Library version is 0x%X\n", l_version);

	err = meQueryNumberDevices(&n_devices);
	if(err){
		meErrorGetMessage(err, err_msg, sizeof(err_msg));
		fprintf(stderr, "In meQueryNumberDevices(): %s\n", err_msg);
		return 1;
	}

	if (n_devices >0)
	{
		err = meQueryVersionMainDriver(&d_version);
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryDriverVersion(): %s\n", err_msg);
			return 1;
		}

		printf("Main driver version is 0x%X\n", d_version);
	}

	printf("%d devices detected by driver system\n", n_devices);

	for(i = 0; i < n_devices; i++){
		printf("\n");
		printf("Device %d:\n", i);
		printf("=========\n");
		err = meQueryNameDevice(i, name_device, sizeof(name_device));
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryDeviceName(): %s\n", err_msg);
			return 1;
		}
		printf("Device name is %s\n", name_device);

		err = meQueryNameDeviceDriver(i, name_driver, sizeof(name_driver));
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryNameDeviceDriver(): %s\n", err_msg);
			return 1;
		}
		printf("Driver name is %s\n", name_driver);

		err = meQueryDescriptionDevice(i, description, sizeof(description));
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryDescriptionDevice(): %s\n", err_msg);
			return 1;
		}
		printf("Device description: %s\n", description);

		err = meQueryVersionDeviceDriver(i, &d_version);
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryDriverName(): %s\n", err_msg);
			return 1;
		}
		printf("Device driver version is 0x%X\n", d_version);

		err = meQueryNumberSubdevices(i, &n_subdevices);
		if(err){
			meErrorGetMessage(err, err_msg, sizeof(err_msg));
			fprintf(stderr, "In meQueryNumberSubdevices(): %s\n", err_msg);
			return 1;
		}
		printf("%d subdevices available:\n", n_subdevices);

		for(j = 0; j < n_subdevices; j++){
			err = meQuerySubdeviceType(i, j, &type, &subtype);
			if(err){
				meErrorGetMessage(err, err_msg, sizeof(err_msg));
				fprintf(stderr, "In meQuerySubdeviceType(): %s\n", err_msg);
				return 1;
			}
			printf("\tSubdevice %d is of type %s (0x%X) and subtype %s (0x%X)\n", j, typetostr(type), type , subtypetostr(subtype), subtype);

			err = meQueryNumberChannels(i, j, &n_channels);
			if(err){
				meErrorGetMessage(err, err_msg, sizeof(err_msg));
				fprintf(stderr, "In meQueryNumberChannels(): %s\n", err_msg);
				return 1;
			}
			printf("\t\tSubdevice %d has %d channels\n", j, n_channels);

			if(type == ME_TYPE_AI || type == ME_TYPE_AO){
				err = meQueryNumberRanges(i, j, ME_UNIT_ANY, &n_ranges);
				if(err){
					meErrorGetMessage(err, err_msg, sizeof(err_msg));
					fprintf(stderr, "In meQueryNumberRanges(): %s\n", err_msg);
					return 1;
				}
				printf("\t\t\tSubdevice %d has %d ranges:\n", j, n_ranges);

				for(k = 0; k < n_ranges; k++){
					err = meQueryRangeInfo(
							i,
							j,
							k,
							&unit,
							&min,
							&max,
							&max_data);
					if(err){
						meErrorGetMessage(err, err_msg, sizeof(err_msg));
						fprintf(stderr, "In meQueryNumberRanges(): %s\n", err_msg);
						return 1;
					}
					printf("\t\t\t\tRange %d: Unit = 0x%X, Min = %lf, Max = %lf, Max Data = %d\n", k, unit, min, max, max_data);
				}
			}
		}
	}

	err = meClose(0);
	if(err){
		meErrorGetMessage(err, err_msg, sizeof(err_msg));
		fprintf(stderr, "In meClose(): %s\n", err_msg);
		return 1;
	}

	return 0;
}

char* typetostr(int number)
{
	if ((number<0x00180001) || (number>0x00180007))
	{
		return meDevTypes[0];
	}

	return meDevTypes[number - 0x00180000];
}

char* subtypetostr(int number)
{
	if ((number<0x00190001) || (number>0x00190004))
	{
		return meSubDevTypes[0];
	}
	return meSubDevTypes[number - 0x00190000];

}
