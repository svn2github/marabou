/* Shared library for Meilhaus driver system.
 * ==========================================
 *
 *  Copyright (C) 2005 Meilhaus Electronic GmbH (support@meilhaus.de)
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Author:	Guenter Gebhardt
 *  Author:	Krzysztof Gantzke	<k.gantzke@meilhaus.de>
 */
#ifdef __KERNEL__
# error This is user space library!
#endif	//__KERNEL__

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <errno.h>
# include <syslog.h>
# include <unistd.h>

# include <float.h>
# include <math.h>

# include "me_error.h"
# include "me_types.h"
# include "me_defines.h"
# include "me_structs.h"
# include "me_ioctl.h"

# include "meids_common.h"
# include "meids_internal.h"
# include "meids_pthread.h"
# include "meids_debug.h"
# include "meids_config_structs.h"
# include "meids_structs.h"
# include "meids_error.c"	/* This file contains only table with errors' descriptions. */

# include "meids.h"
# include "meids_config.h"

/// Standard header file for library.
# include "medriver.h"

# include "pt_100.h"
# include "te_type_b.h"
# include "te_type_e.h"
# include "te_type_j.h"
# include "te_type_k.h"
# include "te_type_n.h"
# include "te_type_r.h"
# include "te_type_s.h"
# include "te_type_t.h"

# include "meids_init.h"

/* Hardware context. Default values. */
#ifndef LIBMEDRIVER_MAX_DEVICES
# define LIBMEDRIVER_MAX_DEVICES	32
#endif

#ifndef LIBMEDRIVER_MAX_SUBDEVICES
# define LIBMEDRIVER_MAX_SUBDEVICES	32
#endif

static int   doSingle(meIOSingle_t* pSingleList, int iCount, int iFlags);

static int   doCreateThread(int device, int subdevice, void* fnThread, void* fnCB, void* contextCB);
static int   doDestroyAllThreads(void);
static int   doDestroyThreads(int device);
static int   doDestroyThread(int device, int subdevice);

static void* irqThread(void* arg);
static void* streamStartThread(void* arg);
static void* streamStopThread(void* arg);
static void* streamNewValuesThread(void* arg);

static double meCalcPT100Temp(double resistance, int iIMeasured);
static double meCalcTCTemp(double dVoltage, double dTeGain,
							double* pdTable, unsigned long ulTableSize,
							double dMinTemp, double dTempOffset);


typedef struct threadsList
{
	struct threadsList*	next;

	pthread_t 			threadID;

	int					device;
	int					subdevice;

	volatile int		cancel;
}
threadsList_t;

typedef struct globalContext
{
	// Protects the file descriptor and the client handles in the device context.
	pthread_mutex_t globalContextMutex;
	pthread_mutex_t callbackContextMutex;
	threadsList_t* activeThreads;
}
globalContext_t;

static globalContext_t globalContext;

static int open_count;
static pthread_mutex_t open_count_mutex;

// Error handling stuff

// Global error - last error's number
static int  meErrno = ME_ERRNO_SUCCESS;
static void SetErrno(int err);
static int  GetErrno(void);
static void meErrorProc(char* text, int err);

static int meErrorDefaultProcFlag = 0; // Flag for default error handler
static void meErrorDefaultProc(char* pcFunction, int iErrorCode);	//Default error handling function
static meErrorCB_t meErrorUserProc = NULL; // User defined error function

///Init and exit of the shared object
void __attribute__((constructor)) meids_global_init(void);
void __attribute__((destructor)) meids_global_fini(void);


///The argument for the external interrupt thread
typedef struct threadContext
{
	threadsList_t* instance;
	union
	{
		meIOStreamCB_t	streamCB;
		meIOIrqCB_t		irqCB;
		void*			fnCB;
	};

	void*	contextCB;
}threadContext_t;


///Library initialization and shutdown
void meids_global_init(void)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	pthread_mutex_init(&open_count_mutex, NULL);
	open_count = 0;

	pthread_mutex_init(&globalContext.globalContextMutex, NULL);
	globalContext.activeThreads = NULL;

	pthread_mutex_init(&globalContext.callbackContextMutex, NULL);
}

void meids_global_fini(void)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (open_count > 0)
	{
		open_count = 1;
		meClose(ME_CLOSE_NO_FLAGS);
	}
}


///Functions to access the driver system

int meOpen(int iFlags)
{
	addr_list_t* config = NULL;
	addr_list_t* nconf;
	int err;
	int err_ret = ME_ERRNO_NOT_OPEN;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	pthread_mutex_lock(&open_count_mutex);
		if (open_count < 0)
			open_count = 0;

		if (!open_count)
		{
			if (!CreateInit(MEIDS_CONF_FILE, &config) && config)
			{
				nconf = config;

				while (nconf)
				{
					err = ME_Open(nconf->addr, nconf->flag);
					if (!err)
						err_ret = err;

					nconf = nconf->next;
				}
				DestroyInit(&config);
			}
		}
		open_count++;
	pthread_mutex_unlock(&open_count_mutex);

	meErrorProc("meOpen()", err_ret);

	return err_ret;
}

int meClose(int iFlags)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	pthread_mutex_lock(&open_count_mutex);
		if (open_count < 0)
			open_count = 0;

		--open_count;

		if (!open_count)
		{
			doDestroyAllThreads();
			err = ME_Close(iFlags);
		}
	pthread_mutex_unlock(&open_count_mutex);

	meErrorProc("meClose()", err);

	return err;
}

int meLockDriver(int iLock, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iLock=%d iFlags=0x%x", iLock, iFlags);

	err = ME_LockAll(iLock, iFlags);

	meErrorProc("meLockDriver()", err);

	return err;
}

int meLockDevice(int iDevice, int iLock, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("device=%d lock=%d flags=0x%x", iDevice,  iLock , iFlags);

	err = ME_LockDevice(iDevice, iLock, iFlags);

	meErrorProc("meLockDevice()", err);

	return err;
}

int meLockSubdevice(int iDevice, int iSubdevice, int iLock, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iDevice=%d iSubdevice=%d iLock=%d iFlags=0x%x", iDevice, iSubdevice, iLock, iFlags);

	err = ME_LockSubdevice(iDevice, iSubdevice, iLock, iFlags);

	meErrorProc("meLockSubdevice()", err);

	return err;
}

///Error handling functions

static void SetErrno(int err)
{
	if(err)
		meErrno = err;
}

static int GetErrno(void)
{
	return meErrno;
}

int meErrorGetLast(int* piErrorCode, int iFlags)
{

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iErrorCode=%d iFlags=%d", iErrorCode, iFlags);

	if (iFlags & ~ME_ERRNO_CLEAR_FLAGS)
	{
		meErrorProc("meErrorGetLast()", ME_ERRNO_INVALID_FLAGS);
		return ME_ERRNO_INVALID_FLAGS;
	}

	if (!piErrorCode)
	{
		meErrorProc("meErrorGetLast()", ME_ERRNO_INVALID_POINTER);
		return ME_ERRNO_INVALID_POINTER;
	}

	*piErrorCode =  GetErrno();
	if (iFlags)
	{
		meErrno = ME_ERRNO_SUCCESS;
	}

	return ME_ERRNO_SUCCESS;
}

int meErrorGetLastMessage(char* pcErrorMsg, int iCount)
{
	return meErrorGetMessage(GetErrno(), pcErrorMsg, iCount);
}

int meErrorGetMessage(int iErrorCode, char* pcErrorMsg, int iCount)
{
	int ret = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iErrorCode=%d iCount=%d", iErrorCode, iCount);

	if (!pcErrorMsg)
	{
		meErrorProc("meErrorGetMessage()", ME_ERRNO_INVALID_POINTER);
		return ME_ERRNO_INVALID_POINTER;
	}

	if (iCount <= 0)
	{
		meErrorProc("meErrorGetMessage()", ME_ERRNO_INVALID_ERROR_MSG_COUNT);
		return ME_ERRNO_INVALID_ERROR_MSG_COUNT;
	}


	if (iErrorCode < ME_ERRNO_SUCCESS)
	{
		strerror_r(-iErrorCode, pcErrorMsg, iCount);
	}
	else if (iErrorCode > ME_ERRNO_INVALID_ERROR_NUMBER)
	{
		LIBPWARNING("ME_ERRNO_INVALID_ERROR_NUMBER");
		strncpy(pcErrorMsg, meErrorMsgTable[ME_ERRNO_INVALID_ERROR_NUMBER], iCount-1);
		ret = ME_ERRNO_INVALID_ERROR_NUMBER;
	}
	else if (strlen(meErrorMsgTable[iErrorCode]) > iCount - 1)
	{
		strncpy(pcErrorMsg, meErrorMsgTable[iErrorCode], iCount - 1);
		ret = ME_ERRNO_INVALID_ERROR_MSG_COUNT;
	}
	else
	{
		strcpy(pcErrorMsg, meErrorMsgTable[iErrorCode]);
	}

	// This is pure paranoia, but to be sure...
	pcErrorMsg[iCount - 1] = '\0';
	return ret;
}

int meErrorSetDefaultProc(int iSwitch)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iSwitch=%d", iSwitch);

	if (iSwitch == ME_SWITCH_ENABLE)
	{
		meErrorDefaultProcFlag = 1;
	}
	else if (iSwitch == ME_SWITCH_DISABLE)
	{
		meErrorDefaultProcFlag = 0;
	}
	else
	{
		LIBPWARNING("ME_ERRNO_INVALID_SWITCH");
		err = ME_ERRNO_INVALID_SWITCH;
	}

	return err;
}

int meErrorSetUserProc(meErrorCB_t pErrorProc)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	meErrorUserProc = pErrorProc;

	return ME_ERRNO_SUCCESS;
}

void meErrorDefaultProc(char* pcFunction, int iErrorCode)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	char msg[ME_ERROR_MSG_MAX_COUNT] = {0};
	meErrorGetMessage(iErrorCode, msg, sizeof(msg));
	fprintf(stderr, "In function %s: %s (%d)\n", pcFunction, msg, iErrorCode);

	LIBPDEBUG("Error (%d) in function %s: %s \n", iErrorCode, pcFunction, msg);
}

/// Internal menagment functions
static int doCreateThread(int device, int subdevice, void* fnThread, void* fnCB, void* contextCB)
{
	threadContext_t* threadArgs;
	threadsList_t* newThread;
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	threadArgs = (threadContext_t *)calloc(1, sizeof(threadContext_t));
	if (!threadArgs)
	{
		LIBPERROR("Can not get requestet memory for new thread's arguments.\n");
		return -ENOMEM;
	}

	newThread = (threadsList_t *)calloc(1, sizeof(threadsList_t));
	if (!newThread)
	{
		free (threadArgs);
		LIBPERROR("Can not get requestet memory for new thread.\n");
		return -ENOMEM;
	}

	pthread_mutex_lock(&globalContext.globalContextMutex);
		newThread->device = device;
		newThread->subdevice = subdevice;
		newThread->cancel = 0;

		threadArgs->instance = newThread;
		threadArgs->fnCB = fnCB;
		threadArgs->contextCB = contextCB;

		if (pthread_create(&newThread->threadID, NULL, fnThread, threadArgs))
		{
			LIBPERROR("device[%d,%d]=>> CREATING THREAD FAILED\n", device, subdevice);
			err = ME_ERRNO_START_THREAD;
			free (newThread);
			free (threadArgs);
		}
		else
		{
			LIBPERROR("device[%d,%d]=>> THREAD CREATED (ID:%lld)\n", device, subdevice, (long long)newThread->threadID);
			pthread_detach(newThread->threadID);

			newThread->next = globalContext.activeThreads;
			globalContext.activeThreads = newThread;
		}
	pthread_mutex_unlock(&globalContext.globalContextMutex);

	return err;
}

static int doDestroyAllThreads(void)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	return doDestroyThreads(-1);
}

static int doDestroyThreads(int device)
{
	LIBPINFO("executed: %s\n", __FUNCTION__);

	return doDestroyThread(device, -1);
}

static int doDestroyThread(int device, int subdevice)
{
	threadsList_t**	activeThread = &globalContext.activeThreads;
	threadsList_t*	deleteThread;
	pthread_t		selfID;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	selfID = pthread_self();
	pthread_mutex_lock(&globalContext.globalContextMutex);
		while (*activeThread)
		{
			if ((device < 0) || (((*activeThread)->device == device) && ((subdevice < 0) || ((*activeThread)->subdevice == subdevice))))
			{
				deleteThread = (*activeThread);

				*activeThread = deleteThread->next;
				if (pthread_equal(deleteThread->threadID, selfID))
				{	// I'm killing yourself. Lord, forgive me, please.
					deleteThread->cancel = 1;
					LIBPDEBUG("killing yourself selfID=%ld\n", selfID);
				}
				else
				{
					deleteThread->cancel = 2;
					pthread_cancel(deleteThread->threadID);
					LIBPDEBUG("killing thread=%ld selfID=%ld\n", deleteThread->threadID, selfID);
					free (deleteThread);
				}
			}
			else
			{
				activeThread = &((*activeThread)->next);
			}
		}
	pthread_mutex_unlock(&globalContext.globalContextMutex);

	return ME_ERRNO_SUCCESS;
}


///Functions to perform I/O on a device

int meIOIrqStart(int iDevice, int iSubdevice, int iChannel, int iIrqSource, int iIrqEdge, int iIrqArg, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_IrqStart(iDevice, iSubdevice, iChannel, iIrqSource, iIrqEdge, iIrqArg, iFlags);

	meErrorProc("meIOIrqStart()", err);

	return err;
}

int meIOIrqStop(int iDevice, int iSubdevice, int iChannel, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_IrqStop(iDevice, iSubdevice, iChannel, iFlags);;

	meErrorProc("meIOIrqStop()", err);

	return err;
}

int meIOIrqWait(int iDevice, int iSubdevice, int iChannel, int* piIrqCount, int* piValue, int iTimeOut, int iFlags)
{
	int err;

	int* piIrqCount_local;
	int* piValue_local;
	int IrqCount_local = 0;
	int Value_local = 0;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	piIrqCount_local = (piIrqCount) ? piIrqCount: &IrqCount_local;
	piValue_local = (piValue) ? piValue : &Value_local;

	if (!(iFlags & ME_IO_IRQ_WAIT_PRESERVE))
	{
		iFlags &= ~ME_IO_IRQ_WAIT_PRESERVE;
	}
	else
	{
		*piIrqCount_local = 0;
	}

	err = ME_IrqWait(iDevice, iSubdevice, iChannel, piIrqCount_local, piValue_local, iTimeOut, iFlags);

	meErrorProc("meIOIrqWait()", err);

	return err;
}

int meIOIrqSetCallback(int iDevice, int iSubdevice, meIOIrqCB_t pCallback, void* pCallbackContext, int iFlags)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iDevice=%d iSubdevice=%d pCallback=%p iFlags=0x%x", iDevice, iSubdevice, pCallback, iFlags);

	if (pCallback)
	{	// create
		err = doCreateThread(iDevice, iSubdevice, irqThread, pCallback, pCallbackContext);
	}
	else
	{	// cancel
		err = doDestroyThread(iDevice, iSubdevice);
	}
	return err;
}

static void* irqThread(void* arg)
{
	threadContext_t	threadArgs;
	threadsList_t*	context;

	int irq_count = 0;
	int value = 0;

	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!arg)
	{
		LIBPCRITICALERROR("No thread context provided!\n");
		pthread_exit (NULL);
		return NULL;
	}

	memcpy(&threadArgs, arg, sizeof(threadContext_t));
	free (arg);
	context = threadArgs.instance;

	LIBPDEBUG("iDevice=%d iSubdevice=%d\n", context->device, context->subdevice);

	if (!threadArgs.irqCB)
	{
		LIBPERROR("device=[%d,%d] ThreadID=%lld =>> No callback registred!\n", context->device, context->subdevice, (long long)context->threadID);
	}

	while (1)
	{
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

		err = ME_IrqWait(context->device, context->subdevice, 0, &irq_count, &value, 100, ME_IO_IRQ_WAIT_NO_FLAGS);
		pthread_testcancel();
		if (context->cancel)
			break;

		if (err == ME_ERRNO_TIMEOUT)
		{// Give chance to destroyer.
			continue;
		}
		/// Interrupt or STOP/RESET -> call callback function.
		if (threadArgs.irqCB)
		{
			pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
			LIBPDEBUG("device[%d,%d] =>> CALLBACK\n", context->device, context->subdevice);
			pthread_mutex_lock(&globalContext.callbackContextMutex);
			if (threadArgs.irqCB(context->device, context->subdevice, 0, irq_count, value, threadArgs.contextCB, err))
			{
				if (context->cancel)
					break;

				if (!err)
				{/// Interrupt ONLY.
					ME_IrqStop(context->device, context->subdevice, 0, ME_IO_IRQ_STOP_NO_FLAGS);
				}
			}
			pthread_mutex_unlock(&globalContext.callbackContextMutex);

			if (context->cancel)
				break;
		}
	} // while()

	if (context->cancel == 1)
		free (context);
	pthread_exit(NULL);
	return NULL;
}


/// @todo Check if 'RESET' should remove callbacks. If not add flag for it.
int meIOResetDevice(int iDevice, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	doDestroyThreads(iDevice);

	err = ME_ResetDevice(iDevice, iFlags);

	meErrorProc("meIOResetDevice()", err);

	return err;
}

int meIOResetSubdevice(int iDevice, int iSubdevice, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	doDestroyThread(iDevice, iSubdevice);

	err = ME_ResetSubdevice(iDevice, iSubdevice, iFlags);

	meErrorProc("meIOResetSubdevice()", err);

	return err;
}

static int doSingle(meIOSingle_t* pSingleList, int iCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("pSingleList=%p iCount=%d iFlags=0x%x", pSingleList, iCount, iFlags);

	if (iCount <= 0)
	{
		LIBPDEBUG("No items in list.");
		return ME_ERRNO_INVALID_SINGLE_LIST;
	}

	if (iCount == 1)
	{
		err = ME_Single(pSingleList[0].iDevice, pSingleList[0].iSubdevice, pSingleList[0].iChannel,
				pSingleList[0].iDir, &pSingleList[0].iValue, pSingleList[0].iTimeOut, pSingleList[0].iFlags);
	}
	else
	{
		err = ME_SingleList(pSingleList, iCount, iFlags);
	}

	return err;
}

int meIOSingle(meIOSingle_t* pSingleList, int iCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!pSingleList)
		return ME_ERRNO_INVALID_POINTER;

	err = doSingle(pSingleList, iCount, iFlags);

	meErrorProc("meIOSingle()", err);

	return err;
}

int meIOSingleConfig(int iDevice, int iSubdevice, int iChannel, int iSingleConfig, int iRef, int iTrigChan, int iTrigType, int iTrigEdge, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_SingleConfig(iDevice, iSubdevice, iChannel, iSingleConfig, iRef, iTrigChan, iTrigType, iTrigEdge, iFlags);

	meErrorProc("meIOSingleConfig()", err);

	return err;
}

int meIOStreamConfig(int iDevice, int iSubdevice, meIOStreamConfig_t* pConfigList, int iCount, meIOStreamTrigger_t* pTrigger, int iFifoIrqThreshold, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamConfig(iDevice, iSubdevice, pConfigList, iCount, pTrigger, iFifoIrqThreshold, iFlags);

	meErrorProc("meIOStreamConfig()", err);

	return err;
}

int meIOStreamNewValues(int iDevice, int iSubdevice, int iTimeOut, int* piCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamNewValues(iDevice, iSubdevice, iTimeOut, piCount, iFlags);

	meErrorProc("meIOStreamConfig()", err);

	return err;
}

int meIOStreamRead(int iDevice, int iSubdevice, int iReadMode, int* piValues, int* piCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamRead(iDevice, iSubdevice, iReadMode, piValues, piCount, 0, iFlags);

	meErrorProc("meIOStreamRead()", err);

	return err;
}

int meIOStreamWrite(int iDevice, int iSubdevice, int iWriteMode, int* piValues, int* piCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamWrite(iDevice, iSubdevice, iWriteMode, piValues, piCount, 0, iFlags);

	meErrorProc("meIOStreamWrite()", err);

	return err;
}

static void* streamStartThread(void* arg)
{
	threadContext_t	threadArgs;
	threadsList_t*	context;

	int streamStatus;
	int value = 0;

	int err = 0;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!arg)
	{
		LIBPCRITICALERROR("No thread context provided!\n");
		pthread_exit (NULL);
		return NULL;
	}

	memcpy(&threadArgs, arg, sizeof(threadContext_t));
	free (arg);
	context = threadArgs.instance;

	LIBPDEBUG("iDevice=%d iSubdevice=%d\n", context->device, context->subdevice);

	if (!threadArgs.streamCB)
	{
		LIBPERROR("device=[%d,%d] ThreadID=%lld =>> No callback registred!\n", context->device, context->subdevice, (long long)context->threadID);
	}

	while (1)
	{
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

		err = ME_StreamStatus(context->device, context->subdevice, ME_WAIT_START, &streamStatus, &value, ME_IO_STREAM_STATUS_NO_FLAGS);
		pthread_testcancel();
		if (context->cancel)
			break;

		/// Start or RESET -> call callback function.
		if (threadArgs.streamCB)
		{
			pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
			LIBPDEBUG("device[%d,%d] =>> CALLBACK\n", context->device, context->subdevice);
			pthread_mutex_lock(&globalContext.callbackContextMutex);
				if (threadArgs.streamCB(context->device, context->subdevice, value, threadArgs.contextCB, err))
				{
					if (context->cancel)
						break;

					if (!err)
					{/// Start ONLY.
						ME_StreamStop(context->device, context->subdevice, 0, ME_IO_IRQ_STOP_NO_FLAGS);
					}
				}
			pthread_mutex_unlock(&globalContext.callbackContextMutex);
			if (context->cancel)
				break;
			}
	} // while()

	if (context->cancel == 1)
		free (context);
	pthread_exit(NULL);
	return NULL;
}

static void* streamStopThread(void* arg)
{
	threadContext_t	threadArgs;
	threadsList_t*	context;

	int streamStatus;
	int value = 0;

	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!arg)
	{
		LIBPCRITICALERROR("No thread context provided!\n");
		pthread_exit (NULL);
		return NULL;
	}

	memcpy(&threadArgs, arg, sizeof(threadContext_t));
	free (arg);
	context = threadArgs.instance;

	LIBPDEBUG("iDevice=%d iSubdevice=%d\n", context->device, context->subdevice);

	if (!threadArgs.streamCB)
	{
		LIBPERROR("device=[%d,%d] ThreadID=%lld =>> No callback registred!\n", context->device, context->subdevice, (long long)context->threadID);
	}

	while (1)
	{
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

		err = ME_StreamStatus(context->device, context->subdevice, ME_WAIT_STOP, &streamStatus, &value, ME_IO_STREAM_STATUS_NO_FLAGS);
		pthread_testcancel();
		if (context->cancel)
			break;

		/// Stop or RESET -> call callback function.
		if (threadArgs.streamCB)
		{
			pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
			LIBPDEBUG("device[%d,%d] =>> CALLBACK\n", context->device, context->subdevice);
			pthread_mutex_lock(&globalContext.callbackContextMutex);
				threadArgs.streamCB(context->device, context->subdevice, value, threadArgs.contextCB, err);
			pthread_mutex_unlock(&globalContext.callbackContextMutex);
			if (context->cancel)
				break;
		}
	} // while()

	if (context->cancel == 1)
		free (context);
	pthread_exit(NULL);
	return NULL;
}

static void* streamNewValuesThread(void* arg)
{
	threadContext_t	threadArgs;
	threadsList_t*	context;

	int value = 0;

	int err = ME_ERRNO_SUCCESS;
	int flag;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!arg)
	{
		LIBPCRITICALERROR("No thread context provided!\n");
		pthread_exit (NULL);
		return NULL;
	}

	memcpy(&threadArgs, arg, sizeof(threadContext_t));
	free (arg);
	context = threadArgs.instance;

	LIBPDEBUG("iDevice=%d iSubdevice=%d\n", context->device, context->subdevice);

	if (!threadArgs.streamCB)
	{
		LIBPERROR("device=[%d,%d] ThreadID=%lld =>> No callback registred!\n", context->device, context->subdevice, (long long)context->threadID);
	}

	while (1)
	{
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
		flag = ME_IO_STREAM_NEW_VALUES_SCREEN_FLAG;
		if (err && (err != ME_ERRNO_TIMEOUT))
		{
			flag |= ME_IO_STREAM_NEW_VALUES_ERROR_REPORT_FLAG;
		}

		err = ME_StreamNewValues(context->device, context->subdevice, 0, &value, flag);
		pthread_testcancel();
		if (context->cancel)
			break;

		if (!err & !value)
			continue;

		/// New values or RESET -> call callback function.
		if (threadArgs.streamCB)
		{
			pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
			LIBPDEBUG("device[%d,%d] =>> CALLBACK\n", context->device, context->subdevice);
			pthread_mutex_lock(&globalContext.callbackContextMutex);
				threadArgs.streamCB(context->device, context->subdevice, value, threadArgs.contextCB, err);
			pthread_mutex_unlock(&globalContext.callbackContextMutex);
			if (context->cancel)
				break;
		}
	} // while()

	if (context->cancel == 1)
		free (context);
	pthread_exit(NULL);
	return NULL;
}

int meIOStreamSetCallbacks(int iDevice, int iSubdevice,
							meIOStreamCB_t pStartCB, void* pStartCBContext,
							meIOStreamCB_t pNewValuesCB, void* pNewValuesCBContext,
							meIOStreamCB_t pEndCB, void* pEndCBContext,
							int iFlags)
{
	int err;
	int err_ret = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPDEBUG("iDevice=%d iSubdevice=%d pStartCB=%p pStartCBContext=%p pNewValuesCB=%p pNewValuesCBContext=%p pEndCB=%p pEndCBContext=%p iFlags=0x%x",
			iDevice, iSubdevice, pStartCB, pStartCBContext, pNewValuesCB, pNewValuesCBContext, pEndCB, pEndCBContext, iFlags);

	if (pNewValuesCB)
	{	// create
		err = doCreateThread(iDevice, iSubdevice, streamNewValuesThread, pNewValuesCB, pNewValuesCBContext);
		meErrorProc("meIOStreamSetCallbacks()", err);
		if (!err_ret)
			err_ret = err;
	}

	if (pStartCB)
	{	// create
		err = doCreateThread(iDevice, iSubdevice, streamStartThread, pStartCB, pStartCBContext);
		meErrorProc("meIOStreamSetCallbacks()", err);
		if (!err_ret)
			err_ret = err;
	}

	if (pEndCB)
	{	// create
		err = doCreateThread(iDevice, iSubdevice, streamStopThread, pEndCB, pEndCBContext);
		meErrorProc("meIOStreamSetCallbacks()", err);
		if (!err_ret)
			err_ret = err;
	}

	if (!pStartCB && !pNewValuesCB && !pEndCB)
	{	// cancel
		err = doDestroyThread(iDevice, iSubdevice);
		meErrorProc("meIOStreamSetCallbacks()", err);
	}

	return err_ret;
}

int meIOStreamStart(meIOStreamStart_t* pStartList, int iCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamStartList(pStartList, iCount, iFlags);

	meErrorProc("meIOStreamStart()", err);

	return err;
}

int meIOStreamStatus(int iDevice, int iSubdevice, int iWait, int* piStatus, int* piCount, int iFlags)
{
	int err;

	int* piStatus_local;
	int* piCount_local;
	int Status_local;
	int Count_local;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	piStatus_local = (piStatus) ? piStatus : &Status_local;
	piCount_local = (piCount) ? piCount : &Count_local;

	err = ME_StreamStatus(iDevice, iSubdevice, iWait, piStatus_local, piCount_local, iFlags);

	meErrorProc("meIOStreamStatus()", err);

	return err;
}

int meIOStreamStop(meIOStreamStop_t* pStopList, int iCount, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamStopList(pStopList, iCount, iFlags);

	meErrorProc("meIOStreamStop()", err);

	return err;
}

int meIOStreamTimeToTicks(int iDevice, int iSubdevice, int iTimer, double* pdTime, int* piTicksLow, int* piTicksHigh, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamTimeToTicks(iDevice, iSubdevice, iTimer, pdTime, piTicksLow, piTicksHigh, iFlags);

	meErrorProc("meIOStreamTimeToTicks()", err);

	return err;
}

int meIOStreamFrequencyToTicks(int iDevice, int iSubdevice, int iTimer, double* pdFrequency, int* piTicksLow, int* piTicksHigh, int iFlags)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_StreamFrequencyToTicks(iDevice, iSubdevice, iTimer, pdFrequency, piTicksLow, piTicksHigh, iFlags);

	meErrorProc("meIOStreamFrequencyToTicks()", err);

	return err;
}


/// Functions to query the driver system

int meQueryVersionLibrary(int* piVersion)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryLibraryVersion(piVersion, ME_QUERY_NO_FLAGS);

	return err;
}


int meQueryDescriptionDevice(int iDevice, char* pcDescription, int iCount)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryDeviceDescription(iDevice, pcDescription, iCount, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryDescriptionDevice()", err);

	return err;
}

int meQueryNameDevice(int iDevice, char* pcName, int iCount)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);
	LIBPINFO("ID:%d\n", iDevice);

	err = ME_QueryDeviceName(iDevice, pcName, iCount, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNameDevice()", err);

	return err;
}

int meQueryNameDeviceDriver(int iDevice, char* pcName, int iCount)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdriverName(iDevice, pcName, iCount, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNameDeviceDriver()", err);

	return err;
}

int meQueryInfoDevice(int iDevice,
						int* piVendorId, int* piDeviceId, int* piSerialNo,
						int* piBusType, int* piBusNo, int* piDevNo, int* piFuncNo,
						int* piPlugged)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryDeviceInfo(iDevice,
							(unsigned int *)piVendorId, (unsigned int *)piDeviceId, (unsigned int *)piSerialNo,
							(unsigned int *)piBusType, (unsigned int *)piBusNo, (unsigned int *)piDevNo, (unsigned int *)piFuncNo,
							piPlugged,
							ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryInfoDevice()", err);

	return err;
}

int meQueryVersionDeviceDriver(int iDevice, int* piVersion)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdriverVersion(iDevice, piVersion, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryVersionDeviceDriver()", err);

	return err;
}

int meQueryVersionMainDriver(int* piVersion)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryDriverVersion(0, piVersion, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryVersionMainDriver()", err);

	return err;
}

int meQueryNumberDevices(int* piNumber)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryDevicesNumber(piNumber, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNumberDevices()", err);

	return err;
}

int meQueryNumberSubdevices(int iDevice, int* piNumber)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdevicesNumber(iDevice, piNumber, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNumberSubdevices()", err);

	return err;
}

int meQueryNumberChannels(int iDevice, int iSubdevice, int* piNumber)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryChannelsNumber(iDevice, iSubdevice, (unsigned int *)piNumber, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNumberChannels()", err);

	return err;
}

int meQueryNumberRanges(int iDevice, int iSubdevice, int iUnit, int* piNumber)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryRangesNumber(iDevice, iSubdevice, iUnit, piNumber, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryNumberRanges()", err);

	return err;
}

int meQueryRangeByMinMax(int iDevice, int iSubdevice, int iUnit, double* pdMin, double* pdMax, int* piMaxData, int* piRange)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryRangeByMinMax(iDevice, iSubdevice, iUnit, pdMin, pdMax, piMaxData, piRange, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryRangeByMinMax()", err);

	return err;
}

int meQueryRangeInfo(int iDevice, int iSubdevice, int iRange, int* piUnit, double* pdMin, double* pdMax, int* piMaxData)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QueryRangeInfo(iDevice, iSubdevice, iRange, piUnit, pdMin, pdMax, (unsigned int *)piMaxData, ME_QUERY_NO_FLAGS);

	meErrorProc("meQueryRangeInfo()", err);

	return err;
}

int meQuerySubdeviceByType(int iDevice, int iStartSubdevice, int iType, int iSubtype, int* piSubdevice)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdeviceByType(iDevice, (iStartSubdevice < 0) ? 0 : iStartSubdevice, iType, iSubtype, piSubdevice, ME_QUERY_NO_FLAGS);

	meErrorProc("meQuerySubdeviceByType()", err);

	return err;
}

int meQuerySubdeviceType(int iDevice, int iSubdevice, int* piType, int* piSubtype)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdeviceType(iDevice, iSubdevice, piType, piSubtype, ME_QUERY_NO_FLAGS);

	meErrorProc("meQuerySubdeviceType()", err);

	return err;
}

int meQuerySubdeviceCaps(int iDevice, int iSubdevice, int* piCaps)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdeviceCaps(iDevice, iSubdevice, piCaps, ME_QUERY_NO_FLAGS);

	meErrorProc("meQuerySubdeviceCaps()", err);

	return err;
}

int meQuerySubdeviceCapsArgs(int iDevice, int iSubdevice, int iCap, int* piArgs, int iCount)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_QuerySubdeviceCapsArgs(iDevice, iSubdevice, iCap, piArgs, iCount, ME_QUERY_NO_FLAGS);

	meErrorProc("meQuerySubdeviceCapsArgs()", err);

	return err;
}


/// Common utility functions

int meUtilityExtractValues(int iChannel,
							int* piAIBuffer, int iAIBufferCount,
							meIOStreamConfig_t* pConfigList, int iConfigListCount,
							int* piChanBuffer, int* piChanBufferCount)
{
	int i = 0;
	int j = 0;
	int k = 0;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!piAIBuffer || !piChanBufferCount || !piChanBuffer)
	{
		meErrorProc("meUtilityExtractValues()", ME_ERRNO_INVALID_POINTER);
		return ME_ERRNO_INVALID_POINTER;
	}

	while (iConfigListCount > 0)
	{
		for (j = 0; j < iConfigListCount; j++)
		{
			if ((k >= *piChanBufferCount) || (i * iConfigListCount + j >= iAIBufferCount))
			{
				*piChanBufferCount = k;
				return ME_ERRNO_SUCCESS;
			}

			if (pConfigList[j].iChannel == iChannel)
			{
				piChanBuffer[k] = piAIBuffer[i * iConfigListCount + j];
				k++;
			}
			else
			{
				continue;
			}
		}

		i++;
	}

	*piChanBufferCount = 0;

	return ME_ERRNO_SUCCESS;
}

int meUtilityPhysicalToDigital(double dMin, double dMax, int iMaxData, double dPhysical, int* piData)
{
	int err = ME_ERRNO_SUCCESS;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!piData)
	{
		err = ME_ERRNO_INVALID_POINTER;
		meErrorProc("meUtilityPhysicalToDigital()", err);
		return err;
	}

	*piData = (dPhysical - dMin) / (dMax - dMin) * iMaxData + 0.5;

	if (*piData < 0)
	{
		*piData = 0;
		err  = ME_ERRNO_VALUE_OUT_OF_RANGE;
	}
	else if (*piData > iMaxData)
	{
		*piData = iMaxData;

		if (dPhysical > dMax)	// This is for covering some possible inaccuracy.
		{
			err  = ME_ERRNO_VALUE_OUT_OF_RANGE;
		}
	}

	meErrorProc("meUtilityPhysicalToDigital()", err);
	return err;
}

static double meCalcPT100Temp(double resistance, int iIMeasured)
{
	int i = 0;
	double grad = ME_PT_100_TEMP_OFFSET;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (resistance < pt_100[i])
	{
		grad = ME_PT_100_TEMP_OFFSET;
		return grad;
	}

	for (i = 0; i < ME_PT_100_TABLE_COUNT; i++)
	{
		if (resistance > pt_100[i])
		{
			continue;
		}
		else if (resistance == pt_100[i])
		{
			grad = i + ME_PT_100_TEMP_OFFSET;
			break;
		}
		else if (resistance < pt_100[i])
		{
			grad = (i - 1) + (1 / (pt_100[i] - pt_100[i - 1])) * (resistance - pt_100[i - 1]) + ME_PT_100_TEMP_OFFSET;
			break;
		}
	}

	if (i == ME_PT_100_TABLE_COUNT)
	{
		grad = ME_PT_100_TABLE_COUNT - 1 + ME_PT_100_TEMP_OFFSET;
	}

	return grad;
}

static double meCalcTCTemp(double dVoltage, double dTeGain,
							double* pdTable, unsigned long ulTableSize,
							double dMinTemp, double dTempOffset)
{
	int i;
	double tevoltage;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	tevoltage = dVoltage / dTeGain * 1E6; // The table holds the voltage in uV

	if (tevoltage <= pdTable[0])
	{
		return pdTable[0];
	}

	if (tevoltage >= pdTable[ulTableSize - 1])
	{
		return pdTable[ulTableSize - 1];
	}

	for (i = 0; i < ulTableSize; i++)
	{
		if (tevoltage == pdTable[i])
		{
			return dMinTemp + i + dTempOffset;
		}
		else if (tevoltage > pdTable[i])
		{
			continue;
		}
		else
		{
			return (((dMinTemp + i) + (tevoltage - pdTable[i]) / (pdTable[i + 1] - pdTable[i])) + dTempOffset);
		}
	}

	return 0.0;
}

int meUtilityDigitalToPhysicalV(double dMin, double dMax, int iMaxData,
								int* piDataBuffer, int iCount,
								int iModuleType, double dRefValue, double* pdPhysicalBuffer)
{
	int err = ME_ERRNO_SUCCESS;
	int i;
	double dResistance;
	//Voltage := (dMax - dMin) / iMaxData * iData + dMin;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (!pdPhysicalBuffer)
		return ME_ERRNO_INVALID_POINTER;

	switch (iModuleType)
	{

		case ME_MODULE_TYPE_MULTISIG_NONE:

		case ME_MODULE_TYPE_MULTISIG_DIFF16_10V:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = (dMax - dMin) / iMaxData * piDataBuffer[i] + dMin;
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_DIFF16_20V:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) * 2;
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_DIFF16_50V:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) * 5;
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_CURRENT16_0_20MA:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = 20E-3 / 10 * ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_RTD8_PT100:
			for (i = 0; i < iCount; i++)
			{
				dResistance = ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) / 40 / dRefValue;
				pdPhysicalBuffer[i] = meCalcPT100Temp(dResistance, dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_RTD8_PT500:
			for (i = 0; i < iCount; i++)
			{
				dResistance = ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) / 8 / dRefValue;
				pdPhysicalBuffer[i] = meCalcPT100Temp(dResistance, dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_RTD8_PT1000:
			for (i = 0; i < iCount; i++)
			{
				dResistance = ((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) / 4 / dRefValue;
				pdPhysicalBuffer[i] = meCalcPT100Temp(dResistance, dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_B:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_B_GAIN,
										te_type_b,
										sizeof(te_type_b) / sizeof(double),
										ME_TE_TYPE_B_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_E:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_E_GAIN,
										te_type_e,
										sizeof(te_type_e) / sizeof(double),
										ME_TE_TYPE_E_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_J:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_J_GAIN,
										te_type_j,
										sizeof(te_type_j) / sizeof(double),
										ME_TE_TYPE_J_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_K:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_K_GAIN,
										te_type_k,
										sizeof(te_type_k) / sizeof(double),
										ME_TE_TYPE_K_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_N:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_N_GAIN,
										te_type_n,
										sizeof(te_type_n) / sizeof(double),
										ME_TE_TYPE_N_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_R:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_R_GAIN,
										te_type_r,
										sizeof(te_type_r) / sizeof(double),
										ME_TE_TYPE_R_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_S:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_S_GAIN,
										te_type_s,
										sizeof(te_type_s) / sizeof(double),
										ME_TE_TYPE_S_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_T:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = meCalcTCTemp(
										((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin),
										ME_TE_TYPE_T_GAIN,
										te_type_t,
										sizeof(te_type_t) / sizeof(double),
										ME_TE_TYPE_T_MIN_TEMP,
										dRefValue);
			}

			break;

		case ME_MODULE_TYPE_MULTISIG_TE8_TEMP_SENSOR:
			for (i = 0; i < iCount; i++)
			{
				pdPhysicalBuffer[i] = (((dMax - dMin) / iMaxData * piDataBuffer[i] + dMin) / 4 - 500E-3) / 10E-3;
			}

			break;

		default:
			err = ME_ERRNO_INVALID_MODULE_TYPE;
	}

	meErrorProc("meUtilityDigitalToPhysical()", err);

	return err;
}

int meUtilityDigitalToPhysical(double dMin, double dMax, int iMaxData, int iData,
	int iModuleType, double dRefValue, double* pdPhysical)
{
	int err = ME_ERRNO_SUCCESS;
	double dResistance;
	double dVoltage = (dMax - dMin) / iMaxData * iData + dMin;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	if (iData == iMaxData+1)
	{
		err = ME_ERRNO_VALUE_OUT_OF_RANGE;
		*pdPhysical = 0;
	}
	else if (iData < 0)
	{
		err = ME_ERRNO_VALUE_OUT_OF_RANGE;
		*pdPhysical = dMin;
	}
	else if (iData > iMaxData+1)
	{
		err = ME_ERRNO_VALUE_OUT_OF_RANGE;
		*pdPhysical = dMax;
	}
	else
	{
		if (!pdPhysical)
			return ME_ERRNO_INVALID_POINTER;

		switch (iModuleType)
		{

			case ME_MODULE_TYPE_MULTISIG_NONE:

			case ME_MODULE_TYPE_MULTISIG_DIFF16_10V:
				*pdPhysical = dVoltage;

				break;

			case ME_MODULE_TYPE_MULTISIG_DIFF16_20V:
				*pdPhysical = dVoltage * 2;

				break;

			case ME_MODULE_TYPE_MULTISIG_DIFF16_50V:
				*pdPhysical = dVoltage * 5;

				break;

			case ME_MODULE_TYPE_MULTISIG_CURRENT16_0_20MA:
				*pdPhysical = 20E-3 / 10 * dVoltage;

				break;

			case ME_MODULE_TYPE_MULTISIG_RTD8_PT100:
				dResistance = dVoltage / 40 / dRefValue;

				*pdPhysical = meCalcPT100Temp(dResistance, dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_RTD8_PT500:
				dResistance = dVoltage / 8 / dRefValue;

				*pdPhysical = meCalcPT100Temp(dResistance, dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_RTD8_PT1000:
				dResistance = dVoltage / 4 / dRefValue;

				*pdPhysical = meCalcPT100Temp(dResistance, dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_B:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_B_GAIN,
								te_type_b,
								sizeof(te_type_b) / sizeof(double),
								ME_TE_TYPE_B_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_E:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_E_GAIN,
								te_type_e,
								sizeof(te_type_e) / sizeof(double),
								ME_TE_TYPE_E_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_J:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_J_GAIN,
								te_type_j,
								sizeof(te_type_j) / sizeof(double),
								ME_TE_TYPE_J_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_K:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_K_GAIN,
								te_type_k,
								sizeof(te_type_k) / sizeof(double),
								ME_TE_TYPE_K_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_N:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_N_GAIN,
								te_type_n,
								sizeof(te_type_n) / sizeof(double),
								ME_TE_TYPE_N_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_R:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_R_GAIN,
								te_type_r,
								sizeof(te_type_r) / sizeof(double),
								ME_TE_TYPE_R_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_S:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_S_GAIN,
								te_type_s,
								sizeof(te_type_s) / sizeof(double),
								ME_TE_TYPE_S_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TYPE_T:
				*pdPhysical = meCalcTCTemp(
								dVoltage,
								ME_TE_TYPE_T_GAIN,
								te_type_t,
								sizeof(te_type_t) / sizeof(double),
								ME_TE_TYPE_T_MIN_TEMP,
								dRefValue);

				break;

			case ME_MODULE_TYPE_MULTISIG_TE8_TEMP_SENSOR:
				*pdPhysical = (dVoltage / 4 - 500E-3) / 10E-3;

				break;

			default:
				err = ME_ERRNO_INVALID_MODULE_TYPE;
		}

		meErrorProc("meUtilityDigitalToPhysical()", err);
	}
	return err;
}

int meUtilityPWMStart(int iDevice, int iSubdevice1, int iSubdevice2, int iSubdevice3, int iRef, int iPrescaler, int iDutyCycle, int iFlag)
{
	int err;
	int type;
	int subtype;
	int i;
	int iRef_C2;
	meIOSingle_t list[3];
	int caps;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	// Check if all of them are counters.
	err = meQuerySubdeviceType(iDevice, iSubdevice1, &type, &subtype);
	if (err)
		return err;

	if (type != ME_TYPE_CTR)
	{
		err = ME_ERRNO_NOT_SUPPORTED;
		meErrorProc("meUtilityPWMStart()", err);
		return err;
	}

	err = meQuerySubdeviceType(iDevice, iSubdevice2, &type, &subtype);
	if (err)
		return err;

	if (type != ME_TYPE_CTR)
	{
		err = ME_ERRNO_NOT_SUPPORTED;
		meErrorProc("meUtilityPWMStart()", err);
		return err;
	}

	err = meQuerySubdeviceType(iDevice, iSubdevice3, &type, &subtype);
	if (err)
		return err;

	if (type != ME_TYPE_CTR)
	{
		err = ME_ERRNO_NOT_SUPPORTED;
		meErrorProc("meUtilityPWMStart()", err);
		return err;
	}


	if (iFlag == ME_PWM_START_CONNECT_INTERNAL)
	{
		// Internally connected: Out_Counter1 >> Clk_Counter2
		// Check if counters are in correct order

		if (iSubdevice1+1 != iSubdevice2)
		{
			err = ME_ERRNO_NOT_SUPPORTED;
			meErrorProc("meUtilityPWMStart()", err);
			return err;
		}

		// Check if internal connections supported by hardware
		// Counter1 >> Counter2
		err = meQuerySubdeviceCaps(iDevice, iSubdevice2, &caps);
		if (err)
			return err;

		if ((caps & ME_CAPS_CTR_CLK_PREVIOUS) != ME_CAPS_CTR_CLK_PREVIOUS)
		{
			err = ME_ERRNO_NOT_SUPPORTED;
			meErrorProc("meUtilityPWMStart()", err);
			return err;
		}

		iRef_C2 = ME_REF_CTR_PREVIOUS;
	}
	else if (iFlag == ME_VALUE_NOT_USED)
	{
		// Extrnal conections - no needs to check anything here
		iRef_C2 = ME_REF_CTR_EXTERNAL;
	}
	else
	{
		/* Wrong flag value */
		err = ME_ERRNO_INVALID_FLAGS;

		meErrorProc("meUtilityPWMStart()", err);
		return err;
	}

	if (iRef != ME_REF_CTR_EXTERNAL)
	{
		// Check if choosen clock source is supported
		err = meQuerySubdeviceCaps(iDevice, iSubdevice1, &caps);
		if (err)
			return err;

		if (iRef == ME_REF_CTR_INTERNAL_1MHZ)
		{
			if ((caps & ME_CAPS_CTR_CLK_INTERNAL_1MHZ) != ME_CAPS_CTR_CLK_INTERNAL_1MHZ)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMStart()", err);
				return err;
			}
		}
		else if (iRef == ME_REF_CTR_INTERNAL_10MHZ)
		{
			if ((caps & ME_CAPS_CTR_CLK_INTERNAL_10MHZ) != ME_CAPS_CTR_CLK_INTERNAL_10MHZ)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMStart()", err);
				return err;
			}
		}
		else if (iRef == ME_REF_CTR_PREVIOUS)
		{
			//This is for me1400D. All counters can be cascaded -> signal's source can be an output from previous counter.

			if ((caps & ME_CAPS_CTR_CLK_PREVIOUS) != ME_CAPS_CTR_CLK_PREVIOUS)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMStart()", err);
				return err;
			}
		}
		else
		{
			//error - no more internal signal's sources!
			err = ME_ERRNO_INVALID_REF;
			meErrorProc("meUtilityPWMStart()", err);
			return err;
		}
	}

	if ((iDutyCycle > 99) || (iDutyCycle < 1))
	{
		err = ME_ERRNO_INVALID_DUTY_CYCLE;
		meErrorProc("meUtilityPWMStart()", err);
		return err;
	}

	err = meIOSingleConfig(iDevice, iSubdevice1, 0, ME_SINGLE_CONFIG_CTR_8254_MODE_2, iRef, ME_TRIG_CHAN_DEFAULT, ME_TRIG_TYPE_SW, 0, ME_IO_SINGLE_CONFIG_NO_FLAGS);
	if (err)
		return err;

	err = meIOSingleConfig( iDevice, iSubdevice2, 0, ME_SINGLE_CONFIG_CTR_8254_MODE_2, iRef_C2, ME_TRIG_CHAN_DEFAULT, ME_TRIG_TYPE_SW, 0, ME_IO_SINGLE_CONFIG_NO_FLAGS);
	if (err)
		return err;

	err = meIOSingleConfig(iDevice, iSubdevice3, 0, ME_SINGLE_CONFIG_CTR_8254_MODE_1, ME_REF_CTR_EXTERNAL, ME_TRIG_CHAN_DEFAULT, ME_TRIG_TYPE_SW, 0, ME_IO_SINGLE_CONFIG_NO_FLAGS);
	if (err)
		return err;

	for (i = 0; i < 3; i++)
	{
		list[i].iDevice = iDevice;
		list[i].iChannel = 0;
		list[i].iDir = ME_DIR_OUTPUT;
		list[i].iFlags = ME_IO_SINGLE_TYPE_NO_FLAGS;
		list[i].iErrno = ME_ERRNO_SUCCESS;
	}

	list[0].iSubdevice = iSubdevice1;

	list[1].iSubdevice = iSubdevice2;
	list[2].iSubdevice = iSubdevice3;

	list[0].iValue = iPrescaler;
	list[1].iValue = 100;
	list[2].iValue = iDutyCycle;

	err = meIOSingle(list, 3, ME_IO_SINGLE_NO_FLAGS);
	if (err)
		return err;

	return ME_ERRNO_SUCCESS;
}

int meUtilityPWMStop(int iDevice, int iSubdevice1)
{
	int err;
	int type;
	int subtype;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = meQuerySubdeviceType(iDevice, iSubdevice1, &type, &subtype);
	if (err)
		return err;

	if ((type != ME_TYPE_CTR))
	{
		err = ME_ERRNO_NOT_SUPPORTED;
		meErrorProc("meUtilityPWMStop()", err);
		return err;
	}

	//Reset prescaler -> block it
	err = meIOResetSubdevice(iDevice, iSubdevice1,ME_IO_RESET_SUBDEVICE_NO_FLAGS);
	if (err)
		return err;

	return ME_ERRNO_SUCCESS;
}

int meUtilityPWMRestart(int iDevice, int iSubdevice1, int iRef, int iPrescaler)
{
	int err;
	int type;
	int subtype;
	int caps;
	meIOSingle_t list;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	/* Check if all of them are counters */
	err = meQuerySubdeviceType(iDevice, iSubdevice1, &type, &subtype);
	if (err)
		return err;

	if (type != ME_TYPE_CTR)
	{
		err = ME_ERRNO_NOT_SUPPORTED;
		meErrorProc("meUtilityPWMRestart()", err);
		return err;
	}

	if (iRef != ME_REF_CTR_EXTERNAL)
	{
		// Check if choosen clock source is supported
		err = meQuerySubdeviceCaps(iDevice, iSubdevice1, &caps);
		if (err)
			return err;

		if (iRef == ME_REF_CTR_INTERNAL_1MHZ)
		{
			if ((caps & ME_CAPS_CTR_CLK_INTERNAL_1MHZ) != ME_CAPS_CTR_CLK_INTERNAL_1MHZ)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMRestart()", err);
				return err;
			}
		}
		else if (iRef == ME_REF_CTR_INTERNAL_10MHZ)
		{
			if ((caps & ME_CAPS_CTR_CLK_INTERNAL_10MHZ) != ME_CAPS_CTR_CLK_INTERNAL_10MHZ)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMRestart()", err);
				return err;
			}
		}
		else if (iRef == ME_REF_CTR_PREVIOUS)
		{
			//This is for me1400D. All counters can be cascaded -> signal's source can be an output from previous counter.

			if ((caps & ME_CAPS_CTR_CLK_PREVIOUS) != ME_CAPS_CTR_CLK_PREVIOUS)
			{
				err = ME_ERRNO_INVALID_REF;
				meErrorProc("meUtilityPWMRestart()", err);
				return err;
			}
		}
		else
		{
			//error - no more internal signal's sources!
			err = ME_ERRNO_INVALID_REF;
			meErrorProc("meUtilityPWMRestart()", err);
			return err;
		}
	}

	//Set mode 2
	err = meIOSingleConfig(iDevice, iSubdevice1, 0, ME_SINGLE_CONFIG_CTR_8254_MODE_2, iRef, ME_TRIG_CHAN_DEFAULT, ME_TRIG_TYPE_SW, 0, ME_IO_SINGLE_CONFIG_NO_FLAGS);
	if (err)
		return err;

	//Start prescaler
	list.iDevice = iDevice;
	list.iChannel = 0;
	list.iDir = ME_DIR_OUTPUT;
	list.iFlags = ME_IO_SINGLE_TYPE_NO_FLAGS;
	list.iErrno = ME_ERRNO_SUCCESS;
	list.iSubdevice = iSubdevice1;
	list.iValue = iPrescaler;

	err = meIOSingle(&list, 1, ME_IO_SINGLE_NO_FLAGS);
	if (err)
		return err;

	return ME_ERRNO_SUCCESS;
}

int meConfigLoad(char* pParamSet)
{
	int err;

	LIBPINFO("executed: %s\n", __FUNCTION__);

	err = ME_ParametersSet((me_extra_param_set_t *)pParamSet, ((me_extra_param_set_t *)pParamSet)->flags);

	meErrorProc("meConfigLoad()", err);

	return err;
}


static void meErrorProc(char* text, int err)
{
	if (err)
	{
		if (meErrorDefaultProcFlag)
			meErrorDefaultProc(text, err);
		if (meErrorUserProc)
			meErrorUserProc(text, err);
	}

	SetErrno(err);
}

void ME_SetErrno(char* text, int err)
{
	if (text)
	{
		meErrorProc(text, err);
	}
	else
	{
		SetErrno(err);
	}
}
