#!/bin/bash
#
# This script is responsible for compile USB modules
#
# Version 1.1
#

if  [ ! -d bin ]; then
    mkdir bin
fi

METMPDIR=`/bin/mktemp -d medirUSB.XXX` || exit 1
install driver/*.c driver/*.h -t ${METMPDIR}
cp MakefileUSB ${METMPDIR}/Makefile
cd ${METMPDIR}
make
cd ..
install ${METMPDIR}/*.ko -t ./bin
rm -f -r ${METMPDIR}
