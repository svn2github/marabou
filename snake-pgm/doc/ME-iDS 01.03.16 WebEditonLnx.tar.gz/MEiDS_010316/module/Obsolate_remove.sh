#!/bin/bash
#
# This script is responsible for removing old (obsolate) drivers.
# The legacy driver are now part of kernel tree.
# Meilhaus Electronic do no support it in kernel 2.6.27 and higher
# It is conflicting with ME-iDS therefore has to be removed.
#
# Only me4600.
#
# Version 1.0
#

KERNEL_VER=`uname -r`
MODDIR=/lib/modules/${KERNEL_VER}/kernel/drivers/staging/me4000
MODNAME=me4000

# Only root is allowed to remove a module
if [ $(whoami) != root ]; then
    echo "You must be root to remove me4000 module!"
    exit 1
fi

# Remove file
if [ -f ${MODDIR}/${MODNAME}.ko ]; then
    echo "Removing ${MODNAME}.ko file!"
    rm -f ${MODDIR}/${MODNAME}.ko
fi

# Remove object
MOD_ENTRY=`/sbin/lsmod | grep ${MODNAME}`
if [ -n "$MOD_ENTRY"  ]; then
    echo "Removing ${MODNAME} driver!"
    rmmod -f ${MODNAME}
# Update dependency
    /sbin/depmod -a
fi

exit 0