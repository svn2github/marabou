#!/bin/bash
#
# This script is responsible for installing
# - drivers (modules)
# - firmwares
# - init scripts
#
# Version 1.2
#
# Change Log:
#
# 28-05-2008
#	* First release.
# 04.07.2008
#	* Coping configuration files moved to library instalation script.
# 10.12.2008
#	* Add checking if install_initd script is installed.

FWDIR=/lib/firmware/
VER=`uname -r`
MODDIR=/lib/modules/${VER}

# Only root is allowed to install a module
if [ $(whoami) != root ]; then
    echo "You must be root to install the init script!"
    exit 1
fi

if  [ ! -d bin ]; then
    echo " "
    echo "Modules not found!"
    echo "Build them first, please."
    exit 1
fi


echo " "
echo "Installing the driver"

mkdir -p ${MODDIR}/extra
install -m 0444 ./bin/*.ko -t ${MODDIR}/extra
/sbin/depmod -a

echo " "
echo "Installing firmwares"
mkdir -p ${FWDIR}
install -m 0444 ../firmware/*.bin -t ${FWDIR}

echo " "
echo "Installing scripts"
cp rcmedriverPCI /etc/init.d/medriverPCI
cp rcmedriverUSB /etc/init.d/medriverUSB

# Let do insserv the runlevel setup
echo "Setup runlevel entries"
if [ -f /usr/lib/lsb/install_initd ]; then
    /usr/lib/lsb/install_initd medriverPCI 
    /usr/lib/lsb/install_initd medriverUSB 
else
    echo " "
    echo "install_initd not found!"
    echo "Please install it. (SUSE: insserv package Ubuntu: 'LSB' package) or add starting scripts to runlevels manualy."
fi

echo " "
echo "Start the driver"
/etc/init.d/medriverPCI start
/etc/init.d/medriverUSB start
