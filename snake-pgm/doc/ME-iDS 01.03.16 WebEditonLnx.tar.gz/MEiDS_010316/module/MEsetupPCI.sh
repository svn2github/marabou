#!/bin/bash
#
# This script is responsible for compile PCI modules
#
# Version 1.0
#

if  [ ! -d bin ]; then
    mkdir bin
fi

METMPDIR=`/bin/mktemp -d medirPCI.XXX` || exit 1
install driver/*.c driver/*.h -t ${METMPDIR}
cp MakefilePCI ${METMPDIR}/Makefile
cd ${METMPDIR}
make
cd ..
install ${METMPDIR}/*.ko -t ./bin
rm -f -r ${METMPDIR}
