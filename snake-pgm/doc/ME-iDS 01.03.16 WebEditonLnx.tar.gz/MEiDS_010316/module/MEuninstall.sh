#!/bin/bash
#
# This script is responsible for uninstalling the meilhaus driver system
#

FWDIR=/lib/firmware/
VER=`uname -r`
MODDIR=/lib/modules/${VER}

# Only root can deinstall the driver
if [ $(whoami) != root ] ; then
    echo "You must be root to deinstall the device driver."
    exit 1
fi

################################
# Actually do the deinstallation
#

echo " "
echo "Removing firmware files in ${FWDIR}."
echo " "
rm -f ${FWDIR}/me*.bin
echo " "
echo "Removing driver"
echo " "

/etc/init.d/medriverPCI stop
/etc/init.d/medriverUSB stop

echo "Removing init scripts."
if [ -f /usr/lib/lsb/remove_initd ]; then
    /usr/lib/lsb/remove_initd medriverPCI
    /usr/lib/lsb/remove_initd medriverUSB
else
    echo " remove_initd not found!"
fi
rm -f /etc/init.d/medriver*

rm -f ${MODDIR}/extra/me*.ko

echo "Update module dependencies."
/sbin/depmod -a
