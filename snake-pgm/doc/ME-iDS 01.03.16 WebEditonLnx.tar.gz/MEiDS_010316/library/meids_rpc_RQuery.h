//
// C++ Interface: meids_local_RQuery
//
// Description:
//
//
// Author: Krzysztof Gantzke <k.gantzke@meilhaus.de>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef __KERNEL__
# ifndef _MEIDS_RPC_RQUERY_H_
#  define _MEIDS_RPC_RQUERY_H_

/// Standard header file for library.
#include <medriver.h>

# endif	//_MEIDS_RPC_RQUERY_H_
#endif	//__KERNEL__
