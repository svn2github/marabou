/* Shared library for Meilhaus driver system (RPC).
 * ==========================================
 *
 *  Copyright (C) 2005 Meilhaus Electronic GmbH (support@meilhaus.de)
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Author:	Krzysztof Gantzke	<k.gantzke@meilhaus.de>
 */
#ifdef __KERNEL__
# error This is user space library!
#endif	//__KERNEL__

# include <stdio.h>
# include <stdlib.h>
# include <errno.h>
# include <syslog.h>

# include <time.h>
# include <float.h>
# include <math.h>
# include <rpc/rpc.h>

# include "me_error.h"
# include "me_types.h"
# include "me_defines.h"
# include "me_structs.h"
# include "me_ioctl.h"
# include "me_common.h"

# include "meids_internal.h"
// # include "meids_pthread.h"
# include "meids_debug.h"
# include "meids_config_structs.h"
# include "meids_structs.h"

# include "meids_rpc.h"
# include "meids_rpc_calls.h"
# include "meids_rpc_config.h"
# include "meids_vrt.h"

static int RPC_init(void);
static int init_calltable(meids_calls_t** context_calls);

// Global variables - keep context and necessary references.
static me_context_list_t*			RPC_Context;
static me_config_t*					RPC_Config;
// static me_config_shortcut_table_t* Local_Table;

static meids_calls_t* RPC_calls;

// Global error - last error's number
static int meErrno = ME_ERRNO_SUCCESS;

/// Init and exit of the shared object
void __attribute__((constructor)) meids_RPC_init(void);
void __attribute__((destructor)) meids_RPC_fini(void);

#define ME_RPC_CONTEXT_INIT(context) \
context = malloc(sizeof(me_rpc_context_t)); \
if (!context) \
{ \
	return 1; \
} \
else \
{ \
	context->context_type = me_context_type_remote; \
	context->context_calls = RPC_calls; \
	context->fd = NULL; \
	/*pthread_mutex_init(&context->rpc_mutex, NULL);*/ \
	context->count = 0; \
	context->device_context = NULL; \
}

/// Private section
void meids_RPC_init(void)
{
	LIBPDEBUG("executed.\n");

	if(RPC_init())
		LIBPERROR("INIT FAILED! \n");
}

void meids_RPC_fini(void)
{
	LIBPDEBUG("executed.\n");

	ME_Close(ME_CLOSE_NO_FLAGS);

	free(RPC_Config);
	free(RPC_Context);
	free(RPC_calls);
}

static int RPC_init(void)
{
	int err, rpc_err;

	ME_CONFIG_INIT(RPC_Config);

	err = context_list_init(&RPC_Context);
	rpc_err = init_calltable(&RPC_calls);

	if (err | rpc_err)
	{
		if (RPC_Context)
			free(RPC_Context);

		if (RPC_Config)
			free(RPC_Config);

		if (RPC_calls)
			free(RPC_calls);

		return -ENOMEM;
	}

	return 0;
}

/// Protected section
int ME_rpc_OpenDriver(const char* address, me_config_t** new_driver, me_rpc_context_t** new_context, int iFlags)
{
	me_config_t* cfg;
	me_rpc_context_t* context;

	int err = ME_ERRNO_OPEN;

	LIBPDEBUG("executed.\n");

	if (!new_driver)
		return ME_ERRNO_INVALID_POINTER;

	ME_RPC_CONTEXT_INIT(context);
	ME_CONFIG_INIT(cfg);

	if (iFlags == ME_OPEN_NO_FLAGS)
		iFlags = ME_OPEN_ALL;

	err = Open_RPC(context, address, ME_OPEN_NO_FLAGS);
	if (!err)
	{
		ConfigRead_RPC(context, cfg, ME_VALUE_NOT_USED);
		ConfigEnumerate(cfg, 0, ME_VALUE_NOT_USED);

		*new_driver = cfg;
		*new_context = context;
	}
	else
	{
		*new_driver = NULL;
		*new_context = NULL;
	}

	return err;
}

int ME_rpc_CloseDriver(void* context, int iFlags)
{

	LIBPDEBUG("executed.\n");

	Close_RPC(context, ME_CLOSE_NO_FLAGS);

	return ME_ERRNO_SUCCESS;
}

int ME_rpc_LockDriver(me_rpc_context_t* context, int lock, int iFlags)
{
 	return LockDriver_RPC(context, lock, iFlags);
}

/// Public section
// Access
int ME_Open(char* address, int iFlags)
{
	me_config_t* new_global_cfg;
	me_config_t* cfg;
	me_rpc_context_t* context;
	int err = ME_ERRNO_OPEN;

	LIBPDEBUG("executed.\n");

	if (address)
	{
		err = ME_rpc_OpenDriver(address, &cfg, &context, iFlags);
		if (!err)
		{
			ConfigJoin(cfg, RPC_Config, &new_global_cfg, ME_VALUE_NOT_USED);
			ConfigClean(RPC_Config, ME_VALUE_NOT_USED);
			ConfigClean(cfg, ME_VALUE_NOT_USED);

			RPC_Config->device_list_count = new_global_cfg->device_list_count;
			RPC_Config->device_list = new_global_cfg->device_list;

			ConfigEnumerate(RPC_Config, 0, ME_VALUE_NOT_USED);
			ContextAppend(context, RPC_Context);
		}
	}
	else
	{
		if (!iFlags || (iFlags & ME_OPEN_RPC))
		{
			err = ME_rpc_OpenDriver("192.168.20.228", &cfg, &context, ME_OPEN_RPC);
			if (!err)
			{
				ConfigJoin(cfg, RPC_Config, &new_global_cfg, ME_VALUE_NOT_USED);
				ConfigClean(RPC_Config, ME_VALUE_NOT_USED);
				ConfigClean(cfg, ME_VALUE_NOT_USED);

				RPC_Config->device_list_count = new_global_cfg->device_list_count;
				RPC_Config->device_list = new_global_cfg->device_list;

				ConfigEnumerate(RPC_Config, 0, ME_VALUE_NOT_USED);
				ContextAppend(context, RPC_Context);
			}
		}
	}

	return err;
}

int ME_Close(int iFlags)
{
	int i = 0;

	me_cfg_device_entry_t** device_list = RPC_Config->device_list;

	LIBPDEBUG("executed.\n");

	if (device_list)
	{
		for (i=0; i<RPC_Config->device_list_count; i++, device_list++)
		{
			ME_rpc_CloseDriver((*device_list)->context, iFlags);
		}
	}

	ConfigClean(RPC_Config, ME_VALUE_NOT_USED);

	LIBPDEBUG("RPC_Config->device_list=0x%p\n", RPC_Config->device_list);
	LIBPDEBUG("RPC_Config->device_list_count=%d\n", RPC_Config->device_list_count);

	return ME_ERRNO_SUCCESS;
}

int ME_QueryDevicesNumber(int* no_devices, int iFlags)
{
	int no;
	me_context_list_t* context_list;
	int err = -14;

	LIBPDEBUG("executed.\n");

	if (iFlags != ME_QUERY_NO_FLAGS)
	{
		LIBPERROR("Invalid flag specified.\n");
		meErrno = ME_ERRNO_INVALID_FLAGS;
		return ME_ERRNO_INVALID_FLAGS;
	}

	CHECK_POINTER(no_devices);

	*no_devices = 0;

	context_list = RPC_Context;
	while (context_list->next)
	{
		if (!QueryDevicesNumber_RPC(context_list->context, &no, ME_QUERY_NO_FLAGS))
		{
			*no_devices += no;
			err = ME_ERRNO_SUCCESS;
		}
		context_list = context_list->next;

	}

	if (err)
		meErrno = err;

	return err;
}

int ME_QueryLibraryVersion(int* version, int iFlags)
{
	LIBPDEBUG("executed.\n");

	CHECK_POINTER(version);

	*version = LIBMEDRIVER_VERSION;
	return ME_ERRNO_SUCCESS;
}

int ME_ConfigRead(me_config_t* cfg, const char* address, int flags)
{
	me_rpc_context_t* context;
	int err;

	LIBPDEBUG("executed.\n");

	CHECK_POINTER(cfg);
	ME_RPC_CONTEXT_INIT(context);

	err = Open_RPC(context, address, ME_OPEN_NO_FLAGS);
	if (!err)
	{
		err = ConfigRead_RPC(context, cfg, flags);
		Close_RPC(context, ME_CLOSE_NO_FLAGS);
	}

	return err;
}

//Lock
/// @todo Lock are wrongly implemented! (Status is not check, multi level locking has no rules, etc.) This is not importand now, but must be re-done before realase.
int ME_LockAll(int lock, int iFlags)
{
	int err = 0;
	me_context_list_t* place = RPC_Context;

	if (!place)
		return -1;

	while (place->next)
	{
		err = LockDriver_RPC(place->context, lock, iFlags);
		if (err)
			break;
		place = place->next;
	}

	return err;
}

int ME_LockDevice(int device, int lock, int iFlags)
{
	return ME_virtual_LockDevice(RPC_Config, device, lock, iFlags);
}

int ME_LockSubdevice(int device, int subdevice, int lock, int iFlags)
{
	return ME_virtual_LockSubdevice(RPC_Config, device, subdevice, lock, iFlags);
}


//Query
int ME_QueryDriverVersion(int device, int* version, int iFlags)
{
	return ME_virtual_QueryDriverVersion(RPC_Config, device, version, iFlags);
}

int ME_QueryDriverName(int device, char* name, int count, int iFlags)
{
	return ME_virtual_QueryDriverName(RPC_Config, device, name, count, iFlags);
}


int ME_QuerySubdriverVersion(int device, int* version, int iFlags)
{
	return ME_virtual_QuerySubdriverVersion(RPC_Config, device, version, iFlags);
}

int ME_QuerySubdriverName(int device, char* name, int count, int iFlags)
{
	return ME_virtual_QuerySubdriverName(RPC_Config, device, name, count, iFlags);
}


int ME_QueryDeviceName(int device, char* name, int count, int iFlags)
{
	return ME_virtual_QueryDeviceName(RPC_Config, device, name, count, iFlags);
}

int ME_QueryDeviceDescription(int device, char* description, int count, int iFlags)
{
	return ME_virtual_QueryDeviceDescription(RPC_Config, device, description, count, iFlags);
}

int ME_QueryDeviceInfo(int device, unsigned int* vendor_id, unsigned int* device_id,
						unsigned int* serial_no, unsigned int* bus_type, unsigned int* bus_no,
						unsigned int* dev_no, unsigned int* func_no, int* plugged, int iFlags)
{
	return ME_virtual_QueryDeviceInfo(RPC_Config, device, vendor_id, device_id, serial_no, bus_type, bus_no, dev_no, func_no, plugged, iFlags);
}


int ME_QuerySubdevicesNumber(int device, int* no_subdevice, int iFlags)
{
	return ME_virtual_QuerySubdevicesNumber(RPC_Config, device, no_subdevice, iFlags);
}

int ME_QuerySubdeviceType(int device, int subdevice, int* type, int* subtype, int iFlags)
{
	return ME_virtual_QuerySubdeviceType(RPC_Config, device, subdevice, type, subtype, iFlags);
}

int ME_QuerySubdeviceByType(int device, int subdevice, int type, int subtype, int* result, int iFlags)
{
	return ME_virtual_QuerySubdeviceByType(RPC_Config, device, subdevice, type, subtype, result, iFlags);
}

int ME_QuerySubdeviceCaps(int device, int subdevice, int* caps, int iFlags)
{
	return ME_virtual_QuerySubdeviceCaps(RPC_Config, device, subdevice, caps, iFlags);
}

int ME_QuerySubdeviceCapsArgs(int device, int subdevice, int cap, int* args, int count, int iFlags)
{
	return ME_virtual_QuerySubdeviceCapsArgs(RPC_Config, device, subdevice, cap, args, count, iFlags);
}


int ME_QueryChannelsNumber(int device, int subdevice, unsigned int* number, int iFlags)
{
	return ME_virtual_QueryChannelsNumber(RPC_Config, device, subdevice, number, iFlags);
}


int ME_QueryRangesNumber(int device, int subdevice, int unit, int* no_ranges, int iFlags)
{
	return ME_virtual_QueryRangesNumber(RPC_Config, device, subdevice, unit, no_ranges, iFlags);
}

int ME_QueryRangeInfo(int device, int subdevice, int range, int* unit, double* min, double* max, unsigned int* max_data, int iFlags)
{
	return ME_virtual_QueryRangeInfo(RPC_Config, device, subdevice, range, unit, min, max, max_data, iFlags);
}

int ME_QueryRangeByMinMax(int device, int subdevice, int unit, double* min, double* max, int* max_data, int* range, int iFlags)
{
	return ME_virtual_QueryRangeByMinMax(RPC_Config, device, subdevice, unit, min, max, max_data, range, iFlags);
}

int ME_QuerySubdeviceTimer(int device, int subdevice,
									int timer, int* base, int* min_ticks_low, int* min_ticks_high, int* max_ticks_low, int* max_ticks_high, int iFlags)
{
	return ME_virtual_QuerySubdeviceTimer(RPC_Config, device, subdevice, timer, base, min_ticks_low, min_ticks_high, max_ticks_low, max_ticks_high, iFlags);
}


//Input/Output
int ME_IrqStart(int device, int subdevice, int channel, int source, int edge, int arg, int iFlags)
{
	return ME_virtual_IrqStart(RPC_Config, device, subdevice, channel, source, edge, arg, iFlags);
}

int ME_IrqWait(int device, int subdevice, int channel, int* count, int* value, int timeout, int iFlags)
{
	return ME_virtual_IrqWait(RPC_Config, device, subdevice, channel, count, value, timeout, iFlags);
}

int ME_IrqStop(int device, int subdevice, int channel, int iFlags)
{
	return ME_virtual_IrqStop(RPC_Config, device, subdevice, channel, iFlags);
}


int ME_ResetDevice(int device, int iFlags)
{
	return ME_virtual_ResetDevice(RPC_Config, device, iFlags);
}

int ME_ResetSubdevice(int device, int subdevice, int iFlags)
{
	return ME_virtual_ResetSubdevice(RPC_Config, device, subdevice, iFlags);
}


int ME_SingleConfig(int device, int subdevice, int channel,
                		int config, int reference, int synchro,
                     	int trigger, int edge, int iFlags)
{
	return ME_virtual_SingleConfig(RPC_Config, device, subdevice, channel, config, reference, synchro, trigger, edge, iFlags);
}

int ME_Single(int device, int subdevice, int channel, int direction, int* value, int timeout, int iFlags)
{
	return ME_virtual_Single(RPC_Config, device, subdevice, channel, direction, value, timeout, iFlags);
}

int ME_SingleList(meIOSingle_t* list, int count, int iFlags)
{
	return ME_virtual_SingleList(RPC_Config, list, count, iFlags);
}


int ME_StreamConfig(int device, int subdevice, meIOStreamConfig_t* list, int count, meIOStreamTrigger_t* trigger, int threshold, int iFlags)
{
	return ME_virtual_StreamConfig(RPC_Config, device, subdevice, list, count, trigger, threshold, iFlags);
}

int ME_StreamConfigure(int device, int subdevice, meIOStreamConfig_t* list, int count, meIOStreamPCITriggers_t* trigger, int threshold, int iFlags)
{
	return ME_virtual_StreamConfigure(RPC_Config, device, subdevice, list, count, trigger, threshold, iFlags);
}

int ME_StreamNewValues(int device, int subdevice, int timeout, int* count, int iFlags)
{
	return ME_virtual_StreamNewValues(RPC_Config, device, subdevice, timeout, count, iFlags);
}

int ME_StreamRead(int device, int subdevice, int mode, int* values, int* count, int timeout, int iFlags)
{
	return ME_virtual_StreamRead(RPC_Config, device, subdevice, mode, values, count, timeout, iFlags);
}

int ME_StreamWrite(int device, int subdevice, int mode, int* values, int* count, int timeout, int iFlags)
{
	return ME_virtual_StreamWrite(RPC_Config, device, subdevice, mode, values, count, timeout, iFlags);
}

int ME_StreamStart(int device, int subdevice, int mode, int timeout, int iFlags)
{
	return ME_virtual_StreamStart(RPC_Config, device, subdevice, mode, timeout, iFlags);
}

int ME_StreamStartList(meIOStreamStart_t* list, int count, int iFlags)
{
	return ME_virtual_StreamStartList(RPC_Config, list, count, iFlags);
}

int ME_StreamStatus(int device, int subdevice, int wait, int* status, int* count, int iFlags)
{
	return ME_virtual_StreamStatus(RPC_Config, device, subdevice, wait, status, count, iFlags);
}

int ME_StreamStop(int device, int subdevice, int mode, int iFlags)
{
	return ME_virtual_StreamStop(RPC_Config, device, subdevice, mode, iFlags);
}

int ME_StreamStopList(meIOStreamStop_t* list, int count, int iFlags)
{
	return ME_virtual_StreamStopList(RPC_Config, list, count, iFlags);
}

int ME_StreamTimeToTicks(int device, int subdevice, int timer, double* stream_time, int* ticks_low, int* ticks_high, int iFlags)
{
	return ME_virtual_StreamTimeToTicks(RPC_Config, device, subdevice, timer, stream_time, ticks_low, ticks_high, iFlags);
}

int ME_StreamFrequencyToTicks(int device, int subdevice, int timer, double* frequency, int* ticks_low, int* ticks_high, int iFlags)
{
	return ME_virtual_StreamTimeToTicks(RPC_Config, device, subdevice, timer, frequency, ticks_low, ticks_high, iFlags);
}

void ME_ConfigPrint(void)
{
	LIBPERROR("RPC_Config=%p\n", RPC_Config);
	LIBPERROR("RPC_Config->device_list_count=%d\n", RPC_Config->device_list_count);
	LIBPERROR("RPC_Config->device_list=%p\n", RPC_Config->device_list);
	ConfigPrint(RPC_Config);
}

int ME_GetErrno(void)
{
	return meErrno;
}

static int init_calltable(meids_calls_t** context_calls)
{
	*context_calls = (meids_calls_t *)malloc(sizeof(meids_calls_t));
	if (!*context_calls)
		return -ENOMEM;

//Lock
	(*context_calls)->LockDevice				= LockDevice_RPC;
	(*context_calls)->LockSubdevice				= LockSubdevice_RPC;

//Query
	(*context_calls)->QueryDriverVersion		= QueryDriverVersion_RPC;
	(*context_calls)->QueryDriverName			= QueryDriverName_RPC;

	(*context_calls)->QuerySubdriverVersion		= QuerySubdriverVersion_RPC;
	(*context_calls)->QuerySubdriverName		= QuerySubdriverName_RPC;

	(*context_calls)->QueryDeviceName			= QueryDeviceName_RPC;
	(*context_calls)->QueryDeviceDescription	= QueryDeviceDescription_RPC;
	(*context_calls)->QueryDeviceInfo			= QueryDeviceInfo_RPC;

	(*context_calls)->QuerySubdevicesNumber		= QuerySubdevicesNumber_RPC;
	(*context_calls)->QuerySubdeviceType		= QuerySubdeviceType_RPC;
	(*context_calls)->QuerySubdeviceByType		= QuerySubdeviceByType_RPC;
	(*context_calls)->QuerySubdeviceCaps		= QuerySubdeviceCaps_RPC;
	(*context_calls)->QuerySubdeviceCapsArgs	= QuerySubdeviceCapsArgs_RPC;

	(*context_calls)->QueryChannelsNumber		= QueryChannelsNumber_RPC;

	(*context_calls)->QueryRangesNumber			= QueryRangesNumber_RPC;
	(*context_calls)->QueryRangeInfo			= QueryRangeInfo_RPC;
	(*context_calls)->QueryRangeByMinMax		= QueryRangeByMinMax_RPC;
	(*context_calls)->QuerySubdeviceTimer		= QuerySubdeviceTimer_RPC;

//Input/Output
	(*context_calls)->IrqStart					= IrqStart_RPC;
	(*context_calls)->IrqWait					= IrqWait_RPC;
	(*context_calls)->IrqStop					= IrqStop_RPC;

	(*context_calls)->ResetDevice				= ResetDevice_RPC;
	(*context_calls)->ResetSubdevice			= ResetSubdevice_RPC;

	(*context_calls)->SingleConfig				= SingleConfig_RPC;
	(*context_calls)->Single					= Single_RPC;
	(*context_calls)->SingleList				= SingleList_RPC;

	(*context_calls)->StreamConfig				= StreamConfig_RPC;
	(*context_calls)->StreamConfigure			= StreamConfigure_RPC;

	(*context_calls)->StreamNewValues			= StreamNewValues_RPC;
	(*context_calls)->StreamRead				= StreamRead_RPC;
	(*context_calls)->StreamWrite				= StreamWrite_RPC;
	(*context_calls)->StreamStart				= StreamStart_RPC;
	(*context_calls)->StreamStartList			= StreamStartList_RPC;
	(*context_calls)->StreamStatus				= StreamStatus_RPC;
	(*context_calls)->StreamStop				= StreamStop_RPC;
	(*context_calls)->StreamStopList			= StreamStopList_RPC;

	(*context_calls)->StreamTimeToTicks			= StreamTimeToTicks_RPC;
	(*context_calls)->StreamFrequencyToTicks	= StreamFrequencyToTicks_RPC;

	return 0;
}
