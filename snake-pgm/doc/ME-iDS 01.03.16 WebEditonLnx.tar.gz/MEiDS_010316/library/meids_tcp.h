#ifndef _MEIDS_TCP_H_
# define _MEIDS_TCP_H_

typedef struct me_cfg_tcpip_hw_info
{
	char *remote_host;
} me_cfg_tcpip_hw_info_t;

#endif	//_MEIDS_TCP_H_
