#!/bin/bash
#
# This script is responsible for installing
# the meilhaus driver system library
#
# Version 1.2
#
# Change Log:
#
# 28-05-2008
#	* Initial release.
# 30-06-2008
#	* Adding installation of configuration files.


echo ""
echo "=========================================================="
echo " This script installs the Meilhaus libraries (MEiDS). "
echo "=========================================================="
echo ""


INCLUDE=/usr/include/medriver
I386_64=x86_64

if [ -z ${LIBRARY} ] ; then
    echo "ERROR: No library to install defined!"
    exit 1
fi

if [ ! -f ${LIBRARY} ] ; then
    echo"ERROR: Library ${LIBRARY} not in place. Please rebuild it!"
    exit 1
fi

DESTINATION_32=/usr/lib
DESTINATION_64=/usr/lib64

#Only root can do the library installation
if [ $(whoami) != root ] ; then
	echo "ERROR: You must be root to install the library!"
	exit 1
fi

# Copy configuration files
CONFIGDIR=/etc/medriver/
echo "Install configuration files to ${CONFIGDIR}"
if [ ! -d ${CONFIGDIR} ] ; then
	mkdir -m 0777 -p ${CONFIGDIR}
fi

install -m 0444 ../config/meconfig.xml ../config/medrvconfig.dtd ../config/meids.config ${CONFIGDIR}
echo ""

if  [ -d ${INCLUDE} ]
then
	rm -r ${INCLUDE}
fi
mkdir ${INCLUDE}

echo "Copy headers to ${INCLUDE}"
cp -f ../osi/*.h ${INCLUDE}
echo ""

if [ -d ${DESTINATION_64} ] ; then
	echo "Copy ${LIBRARY} to ${DESTINATION_64}"
	if cp -f -d ${LIBRARY}* ${DESTINATION_64}
	then
		strip ${DESTINATION_64}/${LIBRARY}
		echo "Run ldconfig on ${DESTINATION_64}"
		if /sbin/ldconfig -n ${DESTINATION_64}
		then
			echo "Installation  in ${DESTINATION_64} was successful."
		else
			echo "ERROR: Cannot run ldconfig on ${DESTINATION_64}!"
		fi
	else
		echo "ERROR: Cannot copy ${LIBRARY} to ${DESTINATION_64}!"
	fi
	echo ""
fi

#This directory always exist!
if [ -d ${DESTINATION_32} ] ; then
	echo "Copy ${LIBRARY} to ${DESTINATION_32}"
	if cp -f -d ${LIBRARY}* ${DESTINATION_32}
	then
		strip ${DESTINATION_32}/${LIBRARY}
		echo "Run ldconfig on ${DESTINATION_32}"
		if /sbin/ldconfig -n ${DESTINATION_32}
		then
			echo "Installation  in ${DESTINATION_32} was successful."
		else
			echo "ERROR: Cannot run ldconfig on ${DESTINATION_32}!"
			exit 1
		fi
	else
		echo "ERROR: Cannot copy ${LIBRARY} to ${DESTINATION_32}!"
		exit 1
	fi
	echo ""
fi
exit 0

