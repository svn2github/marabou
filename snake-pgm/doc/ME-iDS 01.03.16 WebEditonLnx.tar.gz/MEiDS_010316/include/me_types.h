/**
 * @file me_types.h
 *
 * @brief Internal APIs type definitions.
 * @note Copyright (C) 2007 Meilhaus Electronic GmbH (support@meilhaus.de)
 * @author KG (Krzysztof Gantzke) (k.gantzke@meilhaus.de)
 */

#ifndef _ME_TYPES_H_
# define _ME_TYPES_H_

# include "../common/metypes.h"

# include <linux/types.h>
# ifndef __KERNEL__
#  include <stdint.h>
# endif	// __KERNEL__

typedef struct meIOStreamPCITriggers
{
	int start_acq_type;
	uint64_t acq_ticks;

	int start_scan_type;
	uint64_t scan_ticks;

	int start_conv_type;
	uint64_t conv_ticks;

	int trigger_edge;

	int synchro;

	int stop_type;
	int stop_count;

	union
	{
		int args[4];	// Reserved for future use.
	};
}  meIOStreamPCITriggers_t;

#endif
