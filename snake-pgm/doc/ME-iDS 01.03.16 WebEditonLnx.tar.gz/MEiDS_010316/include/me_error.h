/**
 * @file me_error.h
 *
 * @brief Additional errors' definitions. For internal use only.
 * @note Copyright (C) 2008 Meilhaus Electronic GmbH (support@meilhaus.de)
 * @author KG (Krzysztof Gantzke) (k.gantzke@meilhaus.de)
 */

#ifndef _ME_ERROR_H_
# define _ME_ERROR_H_
# include "../common/meerror.h"

# define MEDRV_INTERNAL_ERROR_BASE 			0x1000
# define ME_MUTEX_WRONG_PID 				(MEDRV_INTERNAL_ERROR_BASE + 1)
# define ME_MUTEX_WRONG_STATUS 				(MEDRV_INTERNAL_ERROR_BASE + 2)
# define ME_MUTEX_DEATHLOCK 				(MEDRV_INTERNAL_ERROR_BASE + 3)
# define ME_MUTEX_FORCE 					(MEDRV_INTERNAL_ERROR_BASE + 4)


# define MEiDS_INTERNAL_ERROR_BASE 			(MEDRV_INTERNAL_ERROR_BASE + 0x1000)

/// XML
# define MEiDS_XML_ERROR_BASE       		(MEiDS_INTERNAL_ERROR_BASE + 0x1000)
# define MEiDS_ERRNO_XML_ENTRY_NOT_FOUND  	(MEiDS_XML_ERROR_BASE + 1)
#endif
