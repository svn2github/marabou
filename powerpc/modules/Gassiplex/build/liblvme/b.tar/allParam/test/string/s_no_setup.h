#ifndef S_NO_SETUP_H
#define S_NO_SETUP_H

int s_no_setup(const char *);

#endif
