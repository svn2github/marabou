#ifndef IA_UPPERCASE_H
#define IA_UPPERCASE_H

int ia_uppercase(const char *);

#endif
