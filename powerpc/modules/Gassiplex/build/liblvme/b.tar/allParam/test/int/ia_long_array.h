#ifndef IA_LONG_ARRAY_H
#define IA_LONG_ARRAY_H

int ia_long_array(const char *);

#endif
