#ifndef S_STORE_WHITESPACE_H
#define S_STORE_WHITESPACE_H

int s_store_whitespace(const char *);

#endif
