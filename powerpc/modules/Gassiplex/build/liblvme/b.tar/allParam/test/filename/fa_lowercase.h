#ifndef FA_LOWERCASE_H
#define FA_LOWERCASE_H

int fa_lowercase(const char *);

#endif
