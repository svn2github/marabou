#ifndef SA_SCALAR_H
#define SA_SCALAR_H

int sa_scalar(const char *);

#endif
