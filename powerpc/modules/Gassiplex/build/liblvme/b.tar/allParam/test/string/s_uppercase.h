#ifndef S_UPPERCASE_H
#define S_UPPERCASE_H

int s_uppercase(const char *);

#endif
