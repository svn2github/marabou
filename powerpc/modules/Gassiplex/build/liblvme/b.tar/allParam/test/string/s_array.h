#ifndef S_ARRAY_H
#define S_ARRAY_H

int s_array(const char *);

#endif
