#ifndef IA_LOWERCASE_H
#define IA_LOWERCASE_H

int ia_lowercase(const char *);

#endif
