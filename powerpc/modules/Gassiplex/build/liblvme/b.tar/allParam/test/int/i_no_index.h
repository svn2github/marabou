#ifndef I_NO_INDEX_H
#define I_NO_INDEX_H

int i_no_index(const char *);

#endif
