#ifndef FA_LOWERCASE_NO_BASEDIR_H
#define FA_LOWERCASE_NO_BASEDIR_H

int fa_lowercase_no_basedir(const char *);

#endif
