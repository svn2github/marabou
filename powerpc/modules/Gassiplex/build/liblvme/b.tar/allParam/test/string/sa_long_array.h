#ifndef SA_LONG_ARRAY_H
#define SA_LONG_ARRAY_H

int sa_long_array(const char *);

#endif
