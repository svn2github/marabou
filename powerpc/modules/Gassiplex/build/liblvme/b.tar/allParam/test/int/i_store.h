#ifndef I_STORE_H
#define I_STORE_H

int i_store(const char *);

#endif
