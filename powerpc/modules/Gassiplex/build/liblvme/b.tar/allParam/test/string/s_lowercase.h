#ifndef S_LOWERCASE_H
#define S_LOWERCASE_H

int s_lowercase(const char *);

#endif
