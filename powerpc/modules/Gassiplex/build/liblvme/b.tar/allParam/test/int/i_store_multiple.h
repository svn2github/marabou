#ifndef I_STORE_MULTIPLE_H
#define I_STORE_MULTIPLE_H

int i_store_multiple(const char *);

#endif
