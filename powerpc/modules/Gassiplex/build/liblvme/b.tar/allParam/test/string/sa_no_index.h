#ifndef SA_NO_INDEX_H
#define SA_NO_INDEX_H

int sa_no_index(const char *);

#endif
