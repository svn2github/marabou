#ifndef F_LOWERCASE_REL_NO_BASEDIR_H
#define F_LOWERCASE_REL_NO_BASEDIR_H

int f_lowercase_rel_no_basedir(const char *);

#endif
