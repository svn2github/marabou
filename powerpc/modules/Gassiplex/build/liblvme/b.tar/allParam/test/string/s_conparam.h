#ifndef S_CONPARAM_H
#define S_CONPARAM_H

int s_conparam(const char *);

#endif
