#ifndef IA_STRING_AVAILABLE_H
#define IA_STRING_AVAILABLE_H

int ia_string_available(const char *);

#endif
