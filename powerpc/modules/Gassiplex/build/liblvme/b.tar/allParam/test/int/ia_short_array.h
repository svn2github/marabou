#ifndef IA_SHORT_ARRAY_H
#define IA_SHORT_ARRAY_H

int ia_short_array(const char *);

#endif
