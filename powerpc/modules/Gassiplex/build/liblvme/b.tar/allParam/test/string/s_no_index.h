#ifndef S_NO_INDEX_H
#define S_NO_INDEX_H

int s_no_index(const char *);

#endif
