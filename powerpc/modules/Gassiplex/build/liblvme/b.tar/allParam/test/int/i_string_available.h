#ifndef I_STRING_AVAILABLE_H
#define I_STRING_AVAILABLE_H

int i_string_available(const char *);

#endif
