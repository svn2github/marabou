#ifndef SA_SHORT_ARRAY_H
#define SA_SHORT_ARRAY_H

int sa_short_array(const char *);

#endif
