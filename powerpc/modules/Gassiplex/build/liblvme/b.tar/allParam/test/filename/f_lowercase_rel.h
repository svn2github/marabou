#ifndef F_LOWERCASE_REL_H
#define F_LOWERCASE_REL_H

int f_lowercase_rel(const char *);

#endif
