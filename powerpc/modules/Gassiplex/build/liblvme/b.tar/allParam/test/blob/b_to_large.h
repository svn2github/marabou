#ifndef B_TO_LARGE_H
#define B_TO_LARGE_H

int b_to_large(const char *);

#endif
