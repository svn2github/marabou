#ifndef F_LOWERCASE_ABS_H
#define F_LOWERCASE_ABS_H

int f_lowercase_abs(const char *);

#endif
