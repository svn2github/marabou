#ifndef S_STORE_H
#define S_STORE_H

int s_store(const char *);

#endif
