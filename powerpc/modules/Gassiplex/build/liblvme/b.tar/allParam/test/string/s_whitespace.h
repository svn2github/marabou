#ifndef S_WHITESPACE_H
#define S_WHITESPACE_H

int s_whitespace(const char *);

#endif
