#ifndef I_STORE_EXISTING_H
#define I_STORE_EXISTING_H

int i_store_existing(const char *);

#endif
