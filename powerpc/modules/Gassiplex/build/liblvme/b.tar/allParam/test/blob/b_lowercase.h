#ifndef B_LOWERCASE_H
#define B_LOWERCASE_H

int b_lowercase(const char *);

#endif
