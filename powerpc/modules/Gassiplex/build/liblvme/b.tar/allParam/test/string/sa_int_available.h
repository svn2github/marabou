#ifndef SA_INT_AVAILABLE_H
#define SA_INT_AVAILABLE_H

int sa_int_available(const char *);

#endif
