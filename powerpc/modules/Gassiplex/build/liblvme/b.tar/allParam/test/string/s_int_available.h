#ifndef S_INT_AVAILABLE_H
#define S_INT_AVAILABLE_H

int s_int_available(const char *);

#endif
