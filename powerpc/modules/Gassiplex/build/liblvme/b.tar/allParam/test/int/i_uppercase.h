#ifndef I_UPPERCASE_H
#define I_UPPERCASE_H

int i_uppercase(const char *);

#endif
