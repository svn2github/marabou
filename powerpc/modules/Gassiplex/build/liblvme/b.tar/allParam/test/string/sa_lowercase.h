#ifndef SA_LOWERCASE_H
#define SA_LOWERCASE_H

int sa_lowercase(const char *);

#endif
