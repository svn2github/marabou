#ifndef I_LOWERCASE_H
#define I_LOWERCASE_H

int i_lowercase(const char *);

#endif
