#ifndef IA_NO_INDEX_H
#define IA_NO_INDEX_H

int ia_no_index(const char *);

#endif
