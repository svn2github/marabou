#ifndef SA_UPPERCASE_H
#define SA_UPPERCASE_H

int sa_uppercase(const char *);

#endif
