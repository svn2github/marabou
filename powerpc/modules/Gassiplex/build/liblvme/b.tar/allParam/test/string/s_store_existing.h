#ifndef S_STORE_EXISTING_H
#define S_STORE_EXISTING_H

int s_store_existing(const char *);

#endif
