#ifndef I_NO_SETUP_H
#define I_NO_SETUP_H

int i_no_setup(const char *);

#endif
