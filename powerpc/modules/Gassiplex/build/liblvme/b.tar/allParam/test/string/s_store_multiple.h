#ifndef S_STORE_MULTIPLE_H
#define S_STORE_MULTIPLE_H

int s_store_multiple(const char *);

#endif
