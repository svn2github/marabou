#ifndef I_CONPARAM_H
#define I_CONPARAM_H

int i_conparam(const char *);

#endif
