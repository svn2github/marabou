#ifndef B_ODD_SIZE_H
#define B_ODD_SIZE_H

int b_odd_size(const char *);

#endif
