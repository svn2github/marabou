#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pcache.h"

static int PData_invariant(const PData *my)
{
	int retVal;

	retVal = my != NULL && my->name != NULL && my->idx != NULL && (my->type == PInt);

	return retVal;
}

static PData *newPInt(const char *name, const char *idx, unsigned long int value)
{
	PData *my = malloc(sizeof(PData));

	my->name = malloc(strlen(name) + 1);
	strcpy(my->name, name);

	my->idx = malloc(strlen(idx) + 1);
	strcpy(my->idx, idx);

	my->type = PInt;
	my->value.PInt = value;

	assert(PData_invariant(my));
	return my;
}

static void delPData(PData *my)
{
	if (my != NULL) {
		switch (my->type) {
		case PInt:
			break;
		}
		free(my->idx);
		free(my->name);
		free(my);
	}
}

static int compare(const PData *my, const char *name, const char *idx)
{
	int retVal;

	retVal = strcmp(my->idx, idx);
	if (retVal == 0) {
		retVal = strcmp(my->name, name);
	}
	return retVal < 0 ? -1 : retVal > 0 ? 1 : 0;
}

static PCache *insert(PCache *my, const char *name, const char *idx, unsigned long int value)
{
	if (my == NULL) {
		my = malloc(sizeof(PCache));
		my->r = NULL;
		my->l = NULL;
		my->data = newPInt(name, idx, value);
	} else {
		switch (compare(my->data, name, idx)) {
		case 0:
			delPData(my->data);
			my->data = newPInt(name, idx, value);
			break;
		case -1:
			my->l = insert(my->l, name, idx, value);
			break;
		case 1:
			my->r = insert(my->r, name, idx, value);
			break;
		}
	}
	return my;
}

static PData *find(const PCache *my, const char *name, const char *idx)
{
	PData *retVal;

	if (my == NULL) {
		retVal = NULL;
	} else {
		switch (compare(my->data, name, idx)) {
		case 0:
			retVal = my->data;
			break;
		case -1:
			retVal = find(my->l, name, idx);
			break;
		case 1:
			retVal = find(my->r, name, idx);
			break;
		}
	}
	return retVal;
}

PCache *PCache_storeInt(PCache *my, const char *name, const char *idx, unsigned long int value)
{
	return insert(my, name, idx, value);
}

int PCache_getInt(const PCache *my, const char *name, const char *idx, int *row, unsigned long int *value)
{
	const PData *data;

	data = find(my, name, idx);

	if (data == NULL) {
		*row = 0;
	} else {
		*row = 1;
		*value = data->value.PInt;
	}

	return 0;
}
