static const char rcsId[] = "$Header: /misc/hadaq/cvsroot/allParam/rpc/rpcParam.c,v 1.11 2004/05/26 11:34:38 muench Exp $";
#define _POSIX_C_SOURCE 199509L

#if HAVE_CONFIG_H
#include <config.h>
#endif							/* HAVE_CONFIG_H */

#include <unistd.h>

#include <ctype.h>
#include <errno.h>
#ifdef PTHREADS
#include <pthread.h>
#endif							/* PTHREADS */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <rpc/rpc.h>
#include <sys/stat.h>
#include <sys/utsname.h>

#include "../include/allParam.h"

#include "pcache.h"
#include "rpcParam.h"

static void Param_strerror(Param *, const char *);

typedef struct RpcParamS {
	CLIENT *cl;
	unsigned long remParam;
	PCache *cache;
#ifdef PTHREADS
	pthread_mutex_t *rpcLock;
#endif							/* PTHREADS */
} RpcParam;

int conSetupParam(Param * my, const char *setup)
{
	int retVal = 0;
	RpcParam *rpcParam;
	char *server;
	int row = 0;
	int i = 0;
	struct utsname bufferS, *buffer = &bufferS;

	my->strerror = NULL;

	if (setup != NULL) {
		my->setup = malloc(strlen(setup) + 1);
		strcpy(my->setup, setup);
	} else {
		my->setup = NULL;
	}

	rpcParam = malloc(sizeof(RpcParam));

#ifdef PTHREADS
	rpcParam->rpcLock = malloc(sizeof(pthread_mutex_t));
	pthread_mutex_init(rpcParam->rpcLock, NULL);
#endif							/* PTHREADS */

	server = getenv("PARAM_RPCPAS_ADDR");
	if (server == NULL) {
		Param_strerror(my, "Environment variable PARAM_RPCPAS_ADDR not set");
		retVal = -1;
	} else {
		rpcParam->cl = clnt_create(server, RPCPARAMPROG, RPCPARAMVERS, "tcp");
		if (rpcParam->cl == NULL) {
			Param_strerror(my, clnt_spcreateerror(server));
			retVal = -1;
		} else {
			char *arg;

			arg = my->setup == NULL ? "" : my->setup;
#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
			rpcParam->remParam = *con_1(&arg, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */
		}
	}

	rpcParam->cache = NULL;

	my->specParam = rpcParam;

	my->basedir = malloc(PARAM_MAX_VALUE_LEN);
	uname(buffer);
	while (buffer->nodename[i]) {
		if (!isalnum(buffer->nodename[i])) {
			buffer->nodename[i] = '_';
		}
		i++;
	}
	if (Param_getString
		(my, buffer->nodename, "basedir", &row, my->basedir)
		|| (row != 1)) {
		if (Param_getString(my, "glob", "basedir", &row, my->basedir)
			|| (row != 1)) {
			strcpy(my->basedir, "");
		}
	}
	if ((NULL != my->basedir) && strlen(my->basedir)) {
		strcat(my->basedir, "/");
	}

	return retVal;

}

int conParam(Param * my)
{
	return conSetupParam(my, NULL);
}

void desParam(Param * my)
{
	RpcParam *rpcParam = my->specParam;

	if (rpcParam->cl != NULL) {
#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
		des_1(&rpcParam->remParam, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */
		clnt_destroy(rpcParam->cl);
	}
#ifdef PTHREADS
	pthread_mutex_destroy(rpcParam->rpcLock);
	free(rpcParam->rpcLock);
#endif							/* PTHREADS */
	free(rpcParam);
	free(my->setup);
}

int Param_getInt(const Param * my, const char *name, const char *idx, int *row, unsigned long int *val)
{
	int retVal;
	RpcParam *rpcParam = my->specParam;

	retVal = PCache_getInt(rpcParam->cache, name, idx, row, val);
	if (retVal != 0 || *row == 0) {
		GetScalarArgs args;
		GetIntRes res;

		args.param = rpcParam->remParam;
		args.name = name;
		args.idx = idx;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
		res = *getint_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

		*row = res.rows;
		*val = res.value;

		retVal =  res.ret;
		if (retVal == 0) {
			rpcParam->cache = PCache_storeInt(rpcParam->cache, name, idx, *val);
		}
	}
	return retVal;
}

int Param_getString(const Param * my, const char *name, const char *idx, int *row, char *val)
{
	RpcParam *rpcParam = my->specParam;

	GetScalarArgs args;
	GetStringRes res;

	args.param = rpcParam->remParam;
	args.name = name;
	args.idx = idx;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
	res = *getstring_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

	*row = res.rows;
	strcpy(val, res.value);

	xdr_free(xdr_GetStringRes, &res);

	return res.ret;
}

int Param_getFilename(const Param *my, const char *name, const char *idx,
					  int *row, char *val)
{
	int retVal = 0;
	int rows = 0;
	char value[PARAM_MAX_VALUE_LEN];

	if (((retVal = Param_getString(my, name, idx, &rows, value)) == 0)
		&& (rows == 1)) {
		if (value[0] == '/') {
			strcpy(val, value);
		} else {
			strcpy(val, my->basedir);
			strcat(val, value);
		}
		*row = 1;
	} else {
		*row = 0;
	}
	return retVal;
}

int Param_getIntArray(const Param * my, const char *name, const char *idx, int maxrows, int *rows, unsigned long int *val)
{
	RpcParam *rpcParam = my->specParam;

	GetArrayArgs args;
	GetIntArrayRes res;

	int i;

	args.param = rpcParam->remParam;
	args.name = name;
	args.idx = idx;
	args.maxrows = maxrows;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
	res = *getintarray_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

	*rows = res.value.value_len;
	for (i = 0; i < res.value.value_len; i++) {
		val[i] = res.value.value_val[i];
	}

	xdr_free(xdr_GetStringRes, &res);

	return res.ret;
}

int Param_getStringArray(const Param * my, const char *name, const char *idx, int maxrows, int *rows, char **val)
{
	RpcParam *rpcParam = my->specParam;

	GetArrayArgs args;
	GetStringArrayRes res;

	int i;

	args.param = rpcParam->remParam;
	args.name = name;
	args.idx = idx;
	args.maxrows = maxrows;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
	res = *getstringarray_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

	*rows = res.value.value_len;
	for (i = 0; i < res.value.value_len; i++) {
		strcpy(val[i], res.value.value_val[i]);
	}

	xdr_free(xdr_GetStringRes, &res);

	return res.ret;
}

int Param_getFilenameArray(const Param *my, const char *name,
						   const char *idx, int maxrows, int *rows,
						   char **val)
{
	int retVal = 0;
	int i;
	char *value[PARAM_MAX_ARRAY_LEN];

	for (i = 0; i < maxrows; i++) {
		value[i] = malloc(PARAM_MAX_VALUE_LEN);
	}

	if (((retVal =
		  Param_getStringArray(my, name, idx, maxrows, rows, value)) == 0)
		&& (*rows > 0)) {
		for (i = 0; i < *rows; i++) {
			if (value[i][0] != '/') {
				strcpy(val[i], my->basedir);
				strcat(val[i], value[i]);
			} else {
				strcpy(val[i], value[i]);
			}
		}
	} else {
		*rows = 0;
	}

	for (i = 0; i < maxrows; i++) {
		free(value[i]);
	}

	return retVal;
}

int Param_getBlob(const Param * my, const char *name, const char *idx, size_t * size, FILE ** val)
{
	int retVal = 0;

	retVal = -1;
	Param_strerror(my, "Param_getBlob: Function not implemented");

	return retVal;
}

int Param_storeInt(const Param * my, const char *name, const char *idx, unsigned long int value)
{
	RpcParam *rpcParam = my->specParam;

	StoreIntArgs args;
	int res;

	args.param = rpcParam->remParam;
	args.name = name;
	args.idx = idx;
	args.value = value;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
	res = *storeint_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

	return res;
}

int Param_storeString(const Param * my, const char *name, const char *idx, const char *value)
{
	RpcParam *rpcParam = my->specParam;

	StoreStringArgs args;
	int res;

	args.param = rpcParam->remParam;
	args.name = name;
	args.idx = idx;
	args.value = value;

#ifdef PTHREADS
			pthread_mutex_lock(rpcParam->rpcLock);
#endif							/* PTHREADS */
	res = *storestring_1(&args, rpcParam->cl);
#ifdef PTHREADS
			pthread_mutex_unlock(rpcParam->rpcLock);
#endif							/* PTHREADS */

	return res;
}

void Param_clearCache(const Param * my)
{
}

const char *Param_getErrStr(const Param * my)
{
	return my->strerror;
}

static void Param_strerror(Param * my, const char *strerror)
{
	my->strerror = realloc(my->strerror, strlen(strerror) + 1);
	if (my->strerror != NULL) {
		strcpy(my->strerror, strerror);
	}
}
