#include <rpc/rpc.h>
#include <string.h>

#include <allParam.h>

#include "rpcParam.h"

unsigned long *con_1_svc(char **arg, struct svc_req *svcReq)
{
	static unsigned long res;
	Param *p;
	char *setup;

	p = malloc(sizeof(Param));
	setup = strcmp(*arg, "") == 0 ? NULL : *arg;
	if (conSetupParam(p, setup) == -1) {
		free(p);
		p = NULL;
	}
	res = p;

	return &res;
}

unsigned long *con_1(char **arg, CLIENT *cl) {
	return con_1_svc(arg, NULL);
}

void *des_1_svc(unsigned long *arg, struct svc_req *svcReq)
{
	Param *p = *arg;

	desParam(p);
	free(p);

	return arg;
}

void *des_1(unsigned long *arg, CLIENT *cl) {
	return des_1_svc(arg, NULL);
}

GetIntRes *getint_1_svc(GetScalarArgs * args, struct svc_req * svcReq)
{
	static GetIntRes res;
	Param *p = (Param *) args->param;

	res.ret = Param_getInt(p, args->name, args->idx, &res.rows, &res.value);

	return &res;
}

GetIntRes *getint_1(GetScalarArgs * args, CLIENT *cl) {
	return getint_1_svc(args, NULL);
}

GetStringRes *getstring_1_svc(GetScalarArgs * args, struct svc_req * svcReq)
{
	static GetStringRes res;
	Param *p = (Param *) args->param;

	xdr_free(xdr_GetStringRes, &res);

	res.value = malloc(PARAM_MAX_VALUE_LEN);
	res.ret = Param_getString(p, args->name, args->idx, &res.rows, res.value);

	return &res;
}

GetStringRes *getstring_1(GetScalarArgs * args, CLIENT *cl) {
	return getstring_1_svc(args, NULL);
}

GetStringRes *getfilename_1_svc(GetScalarArgs * args, struct svc_req * svcReq)
{
	static GetStringRes res;
	Param *p = (Param *) args->param;

	xdr_free(xdr_GetStringRes, &res);

	res.value = malloc(PARAM_MAX_VALUE_LEN);
	res.ret = Param_getFilename(p, args->name, args->idx, &res.rows, res.value);

	return &res;
}

GetStringRes *getfilename_1(GetScalarArgs * args, CLIENT *cl) {
	return getfilename_1_svc(args, NULL);
}

GetIntArrayRes *getintarray_1_svc(GetArrayArgs * args, struct svc_req * svcReq)
{
	static GetIntArrayRes res;
	Param *p = (Param *) args->param;

	xdr_free(xdr_GetIntArrayRes, &res);

	res.value.value_val = malloc(args->maxrows * sizeof(unsigned long));
	res.ret = Param_getIntArray(p, args->name, args->idx, args->maxrows, &res.value.value_len, res.value.value_val);

	return &res;
}

GetIntArrayRes *getintarray_1(GetArrayArgs * args, CLIENT *cl) {
	return getintarray_1_svc(args, NULL);
}

GetStringArrayRes *getstringarray_1_svc(GetArrayArgs * args, struct svc_req * svcReq)
{
	static GetStringArrayRes res;
	Param *p = (Param *) args->param;

	int i;

	xdr_free(xdr_GetStringArrayRes, &res);

	res.value.value_val = malloc(args->maxrows * sizeof(char *));
	for (i = 0; i < args->maxrows; i++) {
		res.value.value_val[i] = malloc(PARAM_MAX_VALUE_LEN);
	}
	res.ret = Param_getStringArray(p, args->name, args->idx, args->maxrows, &res.value.value_len, res.value.value_val);

	return &res;
}

GetStringArrayRes *getstringarray_1(GetArrayArgs * args, CLIENT *cl) {
	return getstringarray_1_svc(args, NULL);
}

GetStringArrayRes *getfilenamearray_1_svc(GetArrayArgs * args, struct svc_req * svcReq)
{
	static GetStringArrayRes res;
	Param *p = (Param *) args->param;

	int i;

	xdr_free(xdr_GetStringArrayRes, &res);

	res.value.value_val = malloc(args->maxrows * sizeof(char *));
	for (i = 0; i < args->maxrows; i++) {
		res.value.value_val[i] = malloc(PARAM_MAX_VALUE_LEN);
	}
	res.ret = Param_getFilenameArray(p, args->name, args->idx, args->maxrows, &res.value.value_len, res.value.value_val);

	return &res;
}

GetStringArrayRes *getfilenamearray_1(GetArrayArgs * args, CLIENT *cl) {
	return getfilenamearray_1_svc(args, NULL);
}

int *storeint_1_svc(StoreIntArgs * args, struct svc_req *svcReq)
{
	static int res;
	Param *p = (Param *) args->param;

	res = Param_storeInt(p, args->name, args->idx, args->value);

	return &res;
}

int *storeint_1(StoreIntArgs * args, CLIENT *cl) {
	return storeint_1_svc(args, NULL);
}

int *storestring_1_svc(StoreStringArgs * args, struct svc_req *svcReq)
{
	static int res;
	Param *p = (Param *) args->param;

	res = Param_storeString(p, args->name, args->idx, args->value);

	return &res;
}

int *storestring_1(StoreStringArgs * args, CLIENT *cl) {
	return storestring_1_svc(args, NULL);
}
