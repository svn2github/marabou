
#ifndef PCHE_H
#define PCHE_H

enum PType {
	PInt
};

#if 0
enum PType {
	PInt, PString, PIntArray, PStringArray
};

#endif

struct PDataS {
	char *name;
	char *idx;
	enum PType type;
	union {
		unsigned long int PInt;
		char *PString;
		unsigned long int *PIntArray;
		char **PStringArray;
	} value;
};
typedef struct PDataS PData;

struct PCacheS {
	struct PCacheS *r;
	struct PCacheS *l;
	PData *data;
};
typedef struct PCacheS PCache;

PCache *PCache_storeInt(PCache *my, const char *name, const char *idx, unsigned long int value);
int PCache_getInt(const PCache *my, const char *name, const char *idx, int *row, unsigned long int *value);

#endif
