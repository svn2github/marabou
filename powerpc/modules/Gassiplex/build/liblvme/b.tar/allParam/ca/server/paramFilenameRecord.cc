static const char rcsId[] = "$Header: /misc/hadaq/cvsroot/allParam/ca/server/paramFilenameRecord.cc,v 1.11 2003/05/19 16:30:48 sailer Exp $";
#define _POSIX_C_SOURCE 199509L

#if HAVE_CONFIG_H
#include <config.h>
#endif /* HAVE_CONFIG_H */

extern "C" {
  #include <unistd.h>

  #include <string.h>
}

#include "paramFilenameRecord.h"

ParamFilenameRecord::ParamFilenameRecord(caServer& cas, const Param *p, const char *rn, const char *u) :
  Record(cas, p, rn, u, aitEnumString)
{
	int rows;
	char *tmp[PARAM_MAX_ARRAY_LEN];

	pDest = new ArrayStringDestructor;

	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		tmp[i] = new char[PARAM_MAX_VALUE_LEN];
	}
	if(Param_getFilenameArray(param, name, idx, PARAM_MAX_ARRAY_LEN, &rows, tmp) == 0) {
		index = (unsigned int) rows;
	} else {
		index = 0;
	}
	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		delete [] tmp[i];
	}

	funcTable.installReadFunc("units", &Record::readUnits);
	funcTable.installReadFunc("status", &Record::readStatus);
	funcTable.installReadFunc("severity", &Record::readSeverity);
	funcTable.installReadFunc("seconds", &Record::readSeconds);

	funcTable.installReadFunc("alarmLow", &Record::readAlarmLow);
	funcTable.installReadFunc("alarmHigh", &Record::readAlarmHigh);
	funcTable.installReadFunc("alarmLowWarning", &Record::readAlarmLowWarning);
	funcTable.installReadFunc("alarmHighWarning", &Record::readAlarmHighWarning);
	funcTable.installReadFunc("graphicLow", &Record::readGraphicLow);
	funcTable.installReadFunc("graphicHigh", &Record::readGraphicHigh);
	funcTable.installReadFunc("controlLow", &Record::readControlLow);
	funcTable.installReadFunc("controlHigh", &Record::readControlHigh);
	funcTable.installReadFunc("enums", &Record::readEnums);
	funcTable.installReadFunc("precision", &Record::readPrecision);

	funcTable.installReadFunc("value", &ParamFilenameRecord::readValue);
}

ParamFilenameRecord::~ParamFilenameRecord()
{
	for(unsigned int k = 0 ; k < index ; k++) {
		delete ourValue[k];
	}
}

epicsShareFunc aitEnum ParamFilenameRecord::bestExternalType() const
{
	return aitEnumString;
}

epicsShareFunc unsigned ParamFilenameRecord::maxDimension() const
{
	return 1u;
}

epicsShareFunc aitIndex ParamFilenameRecord::maxBound(unsigned dimension) const
{
	aitIndex retVal;
	if(dimension == 0) {
		retVal = index;
	} else {
		retVal = 1u;
	}
	return retVal;
}

gddAppFuncTableStatus ParamFilenameRecord::readValue(gdd &value)
{
	gddAppFuncTableStatus retVal;
	int pretVal;
	int rows;

	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		ourValue[i] = new char[PARAM_MAX_VALUE_LEN];
	}

	pretVal = Param_getStringArray(param, name, idx, PARAM_MAX_ARRAY_LEN, &rows, ourValue);
	if((pretVal != 0) || ((index = (unsigned int) rows ) == 0)) {
		retVal = S_cas_noRead; 
	} else if(index == 1) {
		aitString stringValue = ourValue[0];

		value.putConvert(stringValue);
		retVal = S_casApp_success;
	} else {
		aitString *stringValue;
		stringValue = new aitString[index];
		for (unsigned int k = 0 ; k < index ; k++) {
			stringValue[k] = ourValue[k];
		}

		value.putRef(stringValue);
		retVal = S_casApp_success;
	}

	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		delete [] ourValue[i];
	}

	return retVal;
}

caStatus ParamFilenameRecord::scan()
{
	caStatus retVal;
	caServer *pCAS = this->getCAS();
	int pretVal;
	int rows;

	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		ourValue[i] = new char[PARAM_MAX_VALUE_LEN];
	}

	pretVal = Param_getStringArray(param, name, idx, PARAM_MAX_ARRAY_LEN, &rows, ourValue);
	if((pretVal != 0) || ((index = (unsigned int) rows ) == 0)) {
		retVal = S_cas_noRead; 
	} else if(index == 1) {
		aitString stringValue = ourValue[0];

		val = new gddScalar(gddAppType_value, aitEnumString);
		val->putConvert(stringValue);
		retVal = S_casApp_success;
	} else {
		aitString *stringValue;
		stringValue = new aitString[index];
		for (unsigned int k = 0 ; k < index ; k++) {
			stringValue[k] = ourValue[k];
		}

		val = new gddAtomic(gddAppType_value, aitEnumString, 1, index);

		val->putRef(stringValue, pDest);
		retVal = S_casApp_success;
	}

	for (int i = 0 ; i < PARAM_MAX_ARRAY_LEN ; i++) {
		delete [] ourValue[i];
	}

	val->setStat(epicsAlarmNone);
	val->setSevr(epicsSevNone);

	if (this->interest == aitTrue && pCAS != NULL) {
#if EPICS_RELEASE >= 314
		casEventMask select(pCAS->valueEventMask()|pCAS->logEventMask()|
							pCAS->alarmEventMask());
#else
		casEventMask select(pCAS->valueEventMask|pCAS->logEventMask|
							pCAS->alarmEventMask);
#endif
		this->postEvent (select, *val);
	}

	return retVal;
}

caStatus ParamFilenameRecord::read(const casCtx &ctx, gdd &prototype)
{
	return ((scan() == S_cas_success) && funcTable.read(*this, prototype));
}

#if EPICS_RELEASE >= 314
caStatus ParamFilenameRecord::write(const casCtx &ctx, const gdd &value)
#else
caStatus ParamFilenameRecord::write(const casCtx &ctx, gdd &value)
#endif
{
	return S_cas_noWrite;
}

