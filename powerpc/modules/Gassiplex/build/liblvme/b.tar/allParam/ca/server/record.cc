static const char rcsId[] = "$Header: /misc/hadaq/cvsroot/allParam/ca/server/record.cc,v 1.9 2003/08/28 12:08:24 sailer Exp $";
#define _POSIX_C_SOURCE 199506L

#if HAVE_CONFIG_H
#include <config.h>
#endif /* HAVE_CONFIG_H */

extern "C" {
#include <unistd.h>

#include <ctype.h>
#include <string.h>
#include <time.h>
}

#include "record.h"

#if EPICS_RELEASE >= 314
Record::Record(caServer &cas, const Param *p, const char *n, const char *u, aitEnum t) : casPV(cas), param(p), units(u), type(t), timer(getCAS()->createTimer())
#else
Record::Record(caServer &cas, const Param *p, const char *n, const char *u, aitEnum t) : casPV(cas), param(p), units(u), type(t)
#endif
{
	char buf1[PARAM_MAX_NAME_LEN];
	char buf2[PARAM_MAX_NAME_LEN];
	char buf3[PARAM_MAX_NAME_LEN];

	strcpy (pPVName, n);
	interest = aitFalse;

	alarmStatus = epicsAlarmNone;
	alarmSeverity = epicsSevNone;

	if(sscanf(pPVName, "HAD:P%*c:%[^:]:%[^:]:%[^:]", buf1, buf2, buf3) != 3) {
		strcpy(name, buf1);
		strcpy(idx, buf2);
	} else {
		strcpy(name, buf2);
		strcpy(idx, buf3);
	}
	for (unsigned int i = 0 ; i < strlen(name) ; i++) {
		name[i] = tolower(name[i]);
	}
	for (unsigned int i = 0 ; i < strlen(idx) ; i++) {
		idx[i] = tolower(idx[i]);
	}

	interest = aitFalse;

	recordScanTimer = new scanTimer(*this);
#if EPICS_RELEASE >= 314
	timer.start(*recordScanTimer, 100.0);
#endif
}

Record::~Record()
{
	delete pDest;
}

void Record::destroy()
{
}

caStatus Record::interestRegister()
{
	interest = aitTrue;
	return S_casApp_success;
}

void Record::interestDelete()
{
	interest = aitFalse;
}

const char *Record::getName() const
{
	return pPVName;
}

aitEnum Record::bestExternalType() const
{
	return type;
}

gddAppFuncTableStatus Record::readUnits(gdd &value)
{
	value.putConvert(*units);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readStatus(gdd &value)
{
	value.putConvert((aitInt32) alarmStatus);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readSeverity(gdd &value)
{
	value.putConvert((aitInt32) alarmSeverity);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readSeconds(gdd &value)
{
	time_t now;
	now = time(NULL);
	value.putConvert((aitUint32) now);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readName(gdd &value)
{
	value.putConvert(pPVName);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readAlarmLow(gdd &value)
{
	value.putConvert(0);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readAlarmHigh(gdd &value)
{
	value.putConvert(2147483647);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readAlarmLowWarning(gdd &value)
{
	value.putConvert(0);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readAlarmHighWarning(gdd &value)
{
	value.putConvert(2147483647);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readGraphicLow(gdd &value)
{
	value.putConvert(0);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readGraphicHigh(gdd &value)
{
	value.putConvert(2147483647);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readControlLow(gdd &value)
{
	value.putConvert(0);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readControlHigh(gdd &value)
{
	value.putConvert(2147483647);
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readEnums(gdd &value)
{
	value.putConvert((aitString) "not implemented");
	return S_casApp_success;
}

gddAppFuncTableStatus Record::readPrecision(gdd &value)
{
	value.putConvert(0);
	return S_casApp_success;
}

#if EPICS_RELEASE >= 314
scanTimer::scanTimer (Record &pv) : procVar(pv)
#else
scanTimer::scanTimer (Record &pv) : osiTimer(100.0), procVar(pv)
#endif
{
}

#if EPICS_RELEASE >= 314
epicsTimerNotify::expireStatus scanTimer::expire(const epicsTime &t)
{
	procVar.scan();
	return expireStatus(restart, 100.0);
}
#else
void scanTimer::expire()
{
	procVar.scan();
}

osiBool scanTimer::again() const
{
	return osiTrue;
}
#endif
