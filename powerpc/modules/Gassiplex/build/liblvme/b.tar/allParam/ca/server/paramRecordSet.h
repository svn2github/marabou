#ifndef PARAMRECORDSET_H
#define PARAMRECORDSET_H

#include <casdef.h>

extern "C" {
#include <allParam.h>
}
#include "record.h"
#define MAX_PARAM_SRC 128
#define MAX_NUM_PV (1024 * 64)
class ParamRecordSet:public caServer {
  private:
	int numPv;
	Record *pvs[MAX_NUM_PV];

	int numParamSrc;
	Param *param[MAX_PARAM_SRC];
	Param *pParam(const char *);

  public:
	 ParamRecordSet(unsigned int);
	~ParamRecordSet();
	pvExistReturn pvExistTest(const casCtx &, const char *);
#if EPICS_RELEASE >= 314
	pvAttachReturn pvAttach(const casCtx & ctx, const char *pPVName);
#else
	pvCreateReturn createPV(const casCtx & ctx, const char *pPVName);
#endif

};

#endif							/* !PARAMRECORDSET_H */
