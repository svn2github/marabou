static const char rcsId[] = "$Header: /misc/hadaq/cvsroot/allParam/ca/server/paramBlobRecord.cc,v 1.15 2003/05/19 16:30:48 sailer Exp $";
#define _POSIX_C_SOURCE 199509L

#if HAVE_CONFIG_H
#include <config.h>
#endif /* HAVE_CONFIG_H */

extern "C" {
  #include <unistd.h>

  #include <stdio.h>
  #include <string.h>
}

#include "paramBlobRecord.h"

#define EPICS_MAX_INDEX 4092

ParamBlobRecord::ParamBlobRecord(caServer& cas, const Param *p, const char *rn, const char *u) :
  Record(cas, p, rn, u, aitEnumUint32)
{
	size_t size;
	FILE *tmp;

	pDest = new ArrayIntDestructor;

	if(Param_getBlob(param, name, idx, &size, &tmp) == 0) {
		index = (unsigned int) ((size - 1) / sizeof(aitUint32)) + 2;
		if (index > EPICS_MAX_INDEX) {
			index = 0;
		}
	} else {
		index = 0;
	}
	fclose(tmp);

	funcTable.installReadFunc("units", &Record::readUnits);
	funcTable.installReadFunc("status", &Record::readStatus);
	funcTable.installReadFunc("severity", &Record::readSeverity);
	funcTable.installReadFunc("seconds", &Record::readSeconds);

	funcTable.installReadFunc("alarmLow", &Record::readAlarmLow);
	funcTable.installReadFunc("alarmHigh", &Record::readAlarmHigh);
	funcTable.installReadFunc("alarmLowWarning", &Record::readAlarmLowWarning);
	funcTable.installReadFunc("alarmHighWarning", &Record::readAlarmHighWarning);
	funcTable.installReadFunc("graphicLow", &Record::readGraphicLow);
	funcTable.installReadFunc("graphicHigh", &Record::readGraphicHigh);
	funcTable.installReadFunc("controlLow", &Record::readControlLow);
	funcTable.installReadFunc("controlHigh", &Record::readControlHigh);
	funcTable.installReadFunc("enums", &Record::readEnums);
	funcTable.installReadFunc("precision", &Record::readPrecision);

	funcTable.installReadFunc("value", &ParamBlobRecord::readValue);
}

ParamBlobRecord::~ParamBlobRecord()
{
}

epicsShareFunc aitEnum ParamBlobRecord::bestExternalType() const
{
	return aitEnumUint32;
}

epicsShareFunc unsigned ParamBlobRecord::maxDimension() const
{
	return 1u;
}

epicsShareFunc aitIndex ParamBlobRecord::maxBound(unsigned dimension) const
{
	aitIndex retVal;
	if(dimension == 0) {
		retVal = index;
	} else {
		retVal = 1u;
	}
	return retVal;
}

gddAppFuncTableStatus ParamBlobRecord::readValue(gdd &value)
{
	FILE *blob;
	size_t size;
	int retVal;

	retVal = Param_getBlob(param, name, idx, &size, &blob);
	index = 2 + (((unsigned int) size - 1) / sizeof(aitUint32));
	if((retVal != 0) || (index == 0) || (index > EPICS_MAX_INDEX)) {
		return S_cas_noRead;
	} else {
		aitUint32 *intValue = new aitUint32[index];
		*intValue = size;
		fread(intValue + 1, sizeof(aitUint32), index - 1, blob);
		fclose(blob);

		value.putRef(intValue);
	}

	return S_casApp_success;
}

caStatus ParamBlobRecord::scan()
{
	FILE *blob;
	size_t size;
	int retVal;

	caServer *pCAS = this->getCAS();

	retVal = Param_getBlob(param, name, idx, &size, &blob);
	index = 2 + (((unsigned int) size - 1) / sizeof(aitUint32));
	if((retVal != 0) || (index == 0) || (index > EPICS_MAX_INDEX)) {
		return S_cas_noRead;
	} else {
		aitUint32 *intValue = new aitUint32[index];
		*intValue = size;
		fread(intValue + 1, sizeof(aitUint32), index - 1, blob);
		fclose(blob);

		val = new gddAtomic(gddAppType_value, aitEnumString, 1, index);

		val->putRef(intValue, pDest);
	}

	val->setStat(epicsAlarmNone);
	val->setSevr(epicsSevNone);

	if (this->interest == aitTrue && pCAS != NULL) {
#if EPICS_RELEASE >= 314
		casEventMask select(pCAS->valueEventMask()|pCAS->logEventMask()|
							pCAS->alarmEventMask());
#else
		casEventMask select(pCAS->valueEventMask|pCAS->logEventMask|
							pCAS->alarmEventMask);
#endif
		this->postEvent (select, *val);
	}

	return S_cas_success;
}

caStatus ParamBlobRecord::read(const casCtx &ctx, gdd &prototype)
{
	return ((scan() == S_cas_success) && funcTable.read(*this, prototype));
}

#if EPICS_RELEASE >= 314
caStatus ParamBlobRecord::write(const casCtx &ctx, const gdd &value)
#else
caStatus ParamBlobRecord::write(const casCtx &ctx, gdd &value)
#endif
{
	return S_cas_noWrite;
}

