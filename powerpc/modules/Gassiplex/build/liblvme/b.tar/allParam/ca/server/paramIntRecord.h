#ifndef PARAMINTRECORD_H
#define PARAMINTRECORD_H

#include "record.h"

class ParamIntRecord : public Record {
  private:
	aitIndex index;
	unsigned long int ourValue[PARAM_MAX_ARRAY_LEN];
	gddAppFuncTable<ParamIntRecord> funcTable;

  public:
	ParamIntRecord(caServer&, const Param *p, const char *rn, const char *u);
	~ParamIntRecord();

	epicsShareFunc aitEnum bestExternalType() const;
	epicsShareFunc unsigned maxDimension() const;
	epicsShareFunc aitIndex maxBound(unsigned int) const;
	gddAppFuncTableStatus readValue(gdd &);

	caStatus scan();
	caStatus read(const casCtx &ctx, gdd &value);
#if EPICS_RELEASE >= 314
	caStatus write(const casCtx &ctx, const gdd &value);
#else
	caStatus write(const casCtx &ctx, gdd &value);
#endif
};

#endif /* !PARAMINTRECORD_H */

