#ifndef PARAMFILENAMERECORD_H
#define PARAMFILENAMERECORD_H

#include "record.h"

class ParamFilenameRecord : public Record {
  private:
	aitIndex index;
	char *ourValue[PARAM_MAX_ARRAY_LEN];
	gddAppFuncTable<ParamFilenameRecord> funcTable;

  public:
	ParamFilenameRecord(caServer&, const Param *p, const char *rn, const char *u);
	~ParamFilenameRecord();

	epicsShareFunc aitEnum bestExternalType() const;
	epicsShareFunc unsigned maxDimension() const;
	epicsShareFunc aitIndex maxBound(unsigned int) const;
	gddAppFuncTableStatus readValue(gdd &);

	caStatus scan();
	caStatus read(const casCtx &ctx, gdd &value);
#if EPICS_RELEASE >= 314
	caStatus write(const casCtx &ctx, const gdd &value);
#else
	caStatus write(const casCtx &ctx, gdd &value);
#endif
};

#endif /* !PARAMFILENAMERECORD_H */

