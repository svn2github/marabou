static const char rcsId[] =
	"$Header: /misc/hadaq/cvsroot/allParam/ca/server/paramServer.cc,v 1.12 2003/08/28 12:08:24 sailer Exp $";
#define _POSIX_C_SOURCE 199506L
#define SYSLOG_NAMES

#if HAVE_CONFIG_H
#include <config.h>
#endif /* HAVE_CONFIG_H */

extern "C" {
extern char *optarg;
extern int optind, opterr, optopt;

#include <unistd.h>

#include <ctype.h>
#include <signal.h>
#include <string.h>
#include <syslog.h>
}

#include <fdManager.h>

#include "paramRecordSet.h"

#define FD_DELAY 1000.0
#ifndef NDEBUG
static void profSignalHandler(int sig)
{
	exit(sig);
}
#endif /* NDEBUG */

static const char *ourBasename(const char *s)
{
	const char *p;

	p = strrchr(s, '/');
	return p != NULL ? p + 1 : s;
}

static void help(const char *name)
{
	fprintf(stdout, "%s: Usage(1): %s [ -d ] [ -v verbosity ] [ -w workdir ]\n", name, name);
	fprintf(stdout, "%s:           Option -d (optional): start as daemon\n",
			name);
	fprintf(stdout, "%s:           Option -v (optional): verbosity,  defaults to info\n", name);
	fprintf(stdout, "%s:           Option -w (optional): workdir for temporary files (needs to be unique)\n", name);
	fprintf(stdout, "%s: Usage(2): %s -h\n", name, name);
	fprintf(stdout, "%s:           Option -h (required): help\n", name);
}

static void usage(const char *name)
{
	fprintf(stderr, "%s: Usage(1): %s [ -d ] [ -v verbosity ] [ -w workdir ]\n", name, name);
	fprintf(stderr, "%s: Usage(2): %s -h\n", name, name);
}

int main(int argc, char *argv[])
{
	int logoption = LOG_PID;
	pid_t myPid = 0;
	int daemon = 0;
	int i;
	char *cwd = NULL;
	int val;
	char *verbosity = NULL;

#ifndef NDEBUG
	signal(SIGQUIT, profSignalHandler);
	signal(SIGTERM, profSignalHandler);
	signal(SIGINT, profSignalHandler);
#endif /* NDEBUG */

	while((val = getopt(argc, argv, "dhv:w:")) != -1) {
		switch(val) {
			case('d'):
				daemon = 1;
				break;
			case('h'):
				help(ourBasename(argv[0]));
				exit(EXIT_SUCCESS);
				break;
			case('v'):
				verbosity = optarg;
				break;
			case('w'):
				cwd = optarg;
				break;
			default:
				usage(ourBasename(argv[0]));
				exit(EXIT_FAILURE);
		}
	}

	if (daemon) {
		if (0 < (myPid = fork())) {
			exit(EXIT_SUCCESS);
		} else {
			setsid();
			if (0 < (myPid = fork())) {
				exit(EXIT_SUCCESS);
			} else {
				if (!cwd) {
					cwd = "/";
				}
				chdir(cwd);
				freopen("/dev/null", "r", stdin);
				freopen("/dev/null", "a", stdout);
				freopen("/dev/console", "a", stderr);
				myPid = getpid();
			}
		}
	} else {
		logoption |= LOG_PERROR;
	}

	openlog(ourBasename(argv[0]), logoption, LOG_LOCAL0);

	if (verbosity == NULL) {
		verbosity = "info";
	}
	for (i = 0; prioritynames[i].c_name != NULL
		&& 0 != strcmp(prioritynames[i].c_name, verbosity); i++) {
	}
	if (prioritynames[i].c_name == NULL) {
		syslog(LOG_ERR, "%s, %d: Unknown verbosity %s. Exiting.",
			   __FILE__, __LINE__, verbosity);
		exit(EXIT_FAILURE);
	} else {
		setlogmask(LOG_UPTO(prioritynames[i].c_val));
	}

	ParamRecordSet *cas;

	if (NULL == (cas = new ParamRecordSet(MAX_NUM_PV))) {
		syslog(LOG_ERR, "Cannot allocate memory for the RecordSet. Exiting.");
		exit(EXIT_FAILURE);
	}                                                                       

	cas->setDebugLevel(0u);

	syslog(LOG_INFO, "%s: Parameter Server ready", argv[0]);
	while (aitTrue) {
		fileDescriptorManager.process(FD_DELAY);
	}

	delete cas;
	closelog();
	return 0;
}

