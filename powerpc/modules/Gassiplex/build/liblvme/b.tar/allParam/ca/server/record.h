#ifndef RECORD_H
#define RECORD_H

#if HAVE_CONFIG_H
#include <config.h>
#endif							/* HAVE_CONFIG_H */

#include <casdef.h>
#if EPICS_RELEASE >= 314
#include <epicsTimer.h>
#else
#include <osiTimer.h>
#endif
#include <aitTypes.h>
#include <aitHelpers.h>
#include <gddApps.h>
#include <gddAppFuncTable.h>

extern "C" {
#include <allParam.h>
}
#include "arrayDest.h"
class scanTimer;

class Record:public casPV {
  protected:
	const Param *param;
	const char *units;
	aitEnum type;
	gdd *val;
#if EPICS_RELEASE >= 314
	 epicsTimer & timer;
#endif
	scanTimer *recordScanTimer;
	aitBool interest;
	epicsAlarmCondition alarmStatus;
	epicsAlarmSeverity alarmSeverity;

	ArrayDestructor *pDest;
	char pPVName[PARAM_MAX_VALUE_LEN];
	char name[PARAM_MAX_VALUE_LEN];
	char idx[PARAM_MAX_VALUE_LEN];

  public:
	 Record(caServer & cas, const Param * p, const char *n, const char *u, aitEnum t);
	~Record();

	void destroy();
	caStatus interestRegister();
	void interestDelete();
	const char *getName() const;
	aitEnum bestExternalType() const;

	inline const char *getPVName() {
		return pPVName;
	} gddAppFuncTableStatus readUnits(gdd &);
	gddAppFuncTableStatus readStatus(gdd &);
	gddAppFuncTableStatus readSeverity(gdd &);
	gddAppFuncTableStatus readSeconds(gdd &);
	gddAppFuncTableStatus readName(gdd &);
	gddAppFuncTableStatus readAlarmLow(gdd &);
	gddAppFuncTableStatus readAlarmHigh(gdd &);
	gddAppFuncTableStatus readAlarmLowWarning(gdd &);
	gddAppFuncTableStatus readAlarmHighWarning(gdd &);
	gddAppFuncTableStatus readGraphicLow(gdd &);
	gddAppFuncTableStatus readGraphicHigh(gdd &);
	gddAppFuncTableStatus readControlLow(gdd &);
	gddAppFuncTableStatus readControlHigh(gdd &);
	gddAppFuncTableStatus readEnums(gdd &);
	gddAppFuncTableStatus readPrecision(gdd &);

	virtual gddAppFuncTableStatus readValue(gdd &) = 0;

	virtual caStatus scan() = 0;
	virtual caStatus read(const casCtx &, gdd &) = 0;
#if EPICS_RELEASE >= 314
	virtual caStatus write(const casCtx &, const gdd &) = 0;
#else
	virtual caStatus write(const casCtx &, gdd &) = 0;
#endif
};

#if EPICS_RELEASE >= 314
class scanTimer:public epicsTimerNotify {
  private:
	Record & procVar;
  public:
	scanTimer(Record &);
	expireStatus expire(const epicsTime & t);
};
#else
class scanTimer:public osiTimer {
  private:
	Record & procVar;
  public:
	scanTimer(Record &);
	void expire();
	osiBool again() const;
};
#endif

#endif							/* !RECORD_H */
