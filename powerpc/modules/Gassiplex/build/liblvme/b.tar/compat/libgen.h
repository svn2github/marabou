/* $Header: /misc/hadaq/cvsroot/compat/libgen.h,v 1.5 2005/03/10 14:53:03 hadaq Exp $ */
#ifndef OUR_LIBGEN_H
#define OUR_LIBGEN_H

#ifdef HAVE_LIBCOMPAT

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#else
#include </usr/include/libgen.h>
#endif

#endif
